import java.net.*;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

// Importaciones necesarias para el manejo de sockets, entrada/salida de datos y Scanner.

public class HiloParImparEjecutar {
    public static void main(String[] args) {
        // Método principal. Se inicia la ejecución del programa aquí.

        // Se crea un nuevo hilo (hilo1) utilizando la clase Thread y se le pasa
        // una instancia de la clase HiloParImpar con el número 2 como argumento.
        // También se le asigna un nombre "Hilo yy".
        Thread hilo1 = new Thread(new HiloParImpar(2), "Hilo yy");

        // Se crea otro hilo (hilo2) de manera similar, pero con el número 1
        // y el nombre "Hilo xx".
        Thread hilo2 = new Thread(new HiloParImpar(1), "Hilo xx");

        // Se inicia la ejecución del hilo1.
        hilo1.start();

        // Se utiliza join() para esperar a que el hilo1 termine su ejecución
        // antes de continuar con la ejecución del hilo2.
        try {
            hilo1.join();
        } catch (InterruptedException e) {
            // En caso de que se produzca una interrupción durante la espera,
            // se imprime el rastreo de la pila del error.
            e.printStackTrace();
        }

        // Una vez que el hilo1 ha terminado, se inicia la ejecución del hilo2.
        hilo2.start();
    }
}

