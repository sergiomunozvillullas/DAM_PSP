import java.net.*;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

// La clase HiloParImpar implementa la interfaz Runnable, lo que significa que puede ser ejecutada por un hilo.
public class HiloParImpar implements Runnable {
    // Variable de instancia privada para almacenar el tipo de hilo (1 para pares, 2 para impares).
    private int tipo;

    // Constructor que recibe un parámetro para determinar el tipo de hilo.
    public HiloParImpar(int tipo) {
        this.tipo = tipo;
    }

    // Método run() que se ejecutará cuando se inicie el hilo.
    @Override
    public void run() {
        // Dependiendo del tipo de hilo, se realizarán diferentes operaciones.
        if (tipo == 1) {
            // Si el tipo es 1, se imprimirán números pares del rango 2 al 100.
            for (int i = 2; i <= 100; i += 2) {
                // Se imprime el nombre del hilo actual junto con el número par generado.
                System.out.println(Thread.currentThread().getName() + " generando número par " + i);
            }
        } else if (tipo == 2) {
            // Si el tipo es 2, se imprimirán números impares del rango 101 al 200.
            for (int i = 101; i <= 200; i += 2) {
                // Se imprime el nombre del hilo actual junto con el número impar generado.
                System.out.println(Thread.currentThread().getName() + " generando número impar " + i);
            }
        }
    }
}

