public class HiloSumasRestas implements Runnable {
    private int numero = 1000;
    private int numveces;
    private String operacion;

    // Constructor de la clase
    public HiloSumasRestas(int numveces, String operacion) {
        this.numveces = numveces;
        this.operacion = operacion;
    }

    // Incrementará numero el numvece indicado
    public int incrementar(int numveces) {
        for (int i = 0; i < numveces; i++) {
            numero++;
        }
        return numero;
    }

    // Decrementará numero el numvece indicado
    public int decrementar(int numveces) {
        for (int i = 0; i < numveces; i++) {
            numero--;
        }
        return numero;
    }

  
    public void run() {
        //while(numero!=900){
        if(operacion=="+"){
        incrementar(numveces);
         System.out.println("Resultado final: " + numero);
        }
        
        if(operacion=="-"){
      	decrementar(numveces);
      	 System.out.println("Resultado final: " + numero);
        }
        
        //}
        
    }

    public static void main(String[] args) {
    
/*

    	HiloSumasRestas hs1 = new HiloSumasRestas(100, "+");
	new Thread(hs1).start();
	HiloSumasRestas hs2 = new HiloSumasRestas(100, "-");
	new Thread(hs2).start();
	HiloSumasRestas hs3 = new HiloSumasRestas(1, "+");
	new Thread(hs3).start();
	HiloSumasRestas hs4 = new HiloSumasRestas(1, "-");
	new Thread(hs4).start();
    

*/

        HiloSumasRestas hs1 = new HiloSumasRestas(100, "+");
        HiloSumasRestas hr2 = new HiloSumasRestas(100, "-");
        //HiloSumasRestas hs3 = new HiloSumasRestas(1, "+");
        //HiloSumasRestas hr4 = new HiloSumasRestas(1, "-");


        Thread threadSuma1 = new Thread(hs1);
        Thread threadResta2 = new Thread(hr2);
        //Thread threadSuma3 = new Thread(hs3);
        //Thread threadResta4 = new Thread(hr4);
        
        // Asignar prioridades
        threadSuma1.setPriority(Thread.MAX_PRIORITY);
        threadResta2.setPriority(Thread.MIN_PRIORITY);
        //threadSuma3.setPriority(Thread.MIN_PRIORITY);
        //threadResta4.setPriority(Thread.MIN_PRIORITY);

        threadSuma1.start();
        threadResta2.start();
        threadSuma3.start();
        threadResta4.start();


      
    }
}

