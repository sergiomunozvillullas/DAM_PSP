public class Ej2 implements Runnable {
	private int numero = 1000;
	private String operacion;
	private int numveces;
	
//Constructor de la clase
	public Ej2(int numveces, String operacion) {
		this.numveces=numveces;
		this.operacion=operacion;
	}
	
	

//Incrementará numero el numvece indicado
	public int incrementar(int numveces) {
		for(int i=0;i<numveces;i++) {
			numero++;
		}
		return numero;
	}

//Decrementará numero el numvece indicado
	public int decrementar(int numveces) {
		
		for(int i=0;i<numveces;i++) {
			numero--;
		}
		return numero;
	}

	public void run() {
        if(operacion=="+"){
        incrementar(numveces);
         System.out.println("Resultado final: " + numero);
        }
        
        if(operacion=="-"){
      	decrementar(numveces);
      	 System.out.println("Resultado final: " + numero);
        }
		
	}
	
	public static void main(String[] args) {
		Ej2 sum1 = new Ej2(100, "+");
		
		Ej2 res1 = new Ej2(100, "-");
		
		Ej2 sum2 = new Ej2(1, "+");
		
		Ej2 res2 = new Ej2(1, "-");
		
		new Thread(sum1).start();
		new Thread(res1).start();
		new Thread(sum2).start();
		new Thread(res2).start();
		
	}
} 
