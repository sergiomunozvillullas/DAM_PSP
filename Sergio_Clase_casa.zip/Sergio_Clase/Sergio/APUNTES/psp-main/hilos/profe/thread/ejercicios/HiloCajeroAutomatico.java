// Clase CuentaBancaria
class CuentaBancaria {
    private int saldo = 1000;

    synchronized void sacarDinero(String nombre, int importe) {
        if (saldo >= importe) {
            System.out.println(nombre + " va a sacar $" + importe);
            saldo -= importe;
            System.out.println("Saldo actual: $" + saldo);
        } else {
            System.out.println(nombre + " no puede sacar dinero. Saldo insuficiente.");
        }

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    synchronized void ingresarDinero(String nombre, int importe) {
        System.out.println(nombre + " va a ingresar $" + importe);
        saldo += importe;
        System.out.println("Saldo actual: $" + saldo);

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}

// Clase HiloSacarDinero
class HiloSacarDinero extends Thread {
    private CuentaBancaria cuenta;
    private String nombre;
    private int cantidad;

    HiloSacarDinero(CuentaBancaria micuenta, String nombre, int cantidad) {
        this.cuenta = micuenta;
        this.nombre = nombre;
        this.cantidad = cantidad;
    }

    public void run() {
        cuenta.sacarDinero(nombre, cantidad);
    }
}

// Clase HiloIngresarDinero
class HiloIngresarDinero extends Thread {
    private CuentaBancaria cuenta;
    private String nombre;
    private int cantidad;

    HiloIngresarDinero(CuentaBancaria micuenta, String nombre, int cantidad) {
        this.cuenta = micuenta;
        this.nombre = nombre;
        this.cantidad = cantidad;
    }

    public void run() {
        cuenta.ingresarDinero(nombre, cantidad);
    }
}

// Clase Principal
public class HiloCajeroAutomatico {
    public static void main(String[] args) {
        CuentaBancaria cuenta = new CuentaBancaria();

        HiloSacarDinero hiloPadre = new HiloSacarDinero(cuenta, "Padre", 200);
        HiloIngresarDinero hiloMadre = new HiloIngresarDinero(cuenta, "Madre", 800);
        HiloSacarDinero hiloHijo1 = new HiloSacarDinero(cuenta, "Hijo1", 300);
        HiloSacarDinero hiloHijo2 = new HiloSacarDinero(cuenta, "Hijo2", 800);
        HiloIngresarDinero hiloAbuelo = new HiloIngresarDinero(cuenta, "Abuelo", 100);

        hiloPadre.start();
        hiloMadre.start();
        hiloHijo1.start();
        hiloHijo2.start();
        hiloAbuelo.start();
    }
}

