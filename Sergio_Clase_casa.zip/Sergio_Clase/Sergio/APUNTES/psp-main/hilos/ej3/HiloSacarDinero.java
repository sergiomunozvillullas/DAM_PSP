import java.net.*;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

// Clase que representa un hilo que saca dinero de una cuenta bancaria
class HiloSacarDinero extends Thread {
    private CuentaBancaria cuenta; // Referencia a la cuenta bancaria de donde se sacará el dinero
    private String nombre; // Nombre del hilo (quien está realizando la operación)
    private int cantidad; // Cantidad de dinero que se sacará de la cuenta

    // Constructor de la clase HiloSacarDinero
    public HiloSacarDinero(CuentaBancaria micuenta, String nombre, int cantidad) {
        this.cuenta = micuenta; // Asignar la cuenta bancaria
        this.nombre = nombre; // Asignar el nombre del hilo
        this.cantidad = cantidad; // Asignar la cantidad de dinero a sacar
    }

    // Método run() que se ejecutará cuando el hilo comience su ejecución
    public void run() {
        cuenta.sacarDinero(nombre, cantidad); // Llamar al método de la cuenta bancaria para sacar el dinero
    }
}

