import java.net.*;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

// Definición de la clase HiloSumasRestas que implementa la interfaz Runnable
public class HiloSumasRestas implements Runnable {
    private static int numero = 1000; // Declaración de la variable compartida 'numero', ahora es estática
    private final int numVeces;
    private final String operacion;

    // Constructor de la clase HiloSumasRestas
    public HiloSumasRestas(int numVeces, String operacion) {
        this.numVeces = numVeces;
        this.operacion = operacion;
    }

    // Método para incrementar el número compartido de forma sincronizada
    public static synchronized void incrementar(int numVeces) {
        numero += numVeces;
    }

    // Método para decrementar el número compartido de forma sincronizada
    public static synchronized void decrementar(int numVeces) {
        numero -= numVeces;
    }

    // Implementación del método run() de la interfaz Runnable
    @Override
    public void run() {
        // Verificar la operación a realizar
        if ("+".equals(operacion)) {
            incrementar(numVeces); // Incrementar el número compartido
            System.out.println("+" + numVeces);
        } else if ("-".equals(operacion)) {
            decrementar(numVeces); // Decrementar el número compartido
            System.out.println("-" + numVeces);
        }
    }

    // Método estático para obtener el valor actual del número compartido
    public static int getNumero() {
        return numero;
    }
}

