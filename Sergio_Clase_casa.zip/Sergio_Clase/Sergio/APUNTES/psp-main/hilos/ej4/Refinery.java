import java.net.*;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

// Clase principal que representa una refinería
public class Refinery {
    // Constantes que definen parámetros relacionados con la refinería
    public static final int NUM_OF_TRUCKS = 3; // Número de camiones
    public static final int LITERS_PER_CHARGE_RANDOM_LIMIT = 1000; // Límite de litros por carga aleatoria
    public static final int NUM_OF_LOAD = 15; // Número total de cargas a realizar
    public static final int NUM_OF_LOAD_PER_TRUCK = 5; // Número de cargas por camión

    private static final Deposit DEPOSIT = new Deposit(); // Depósito compartido por los productores y camiones

    // Método principal que inicia la simulación
    public static void main(String[] args) {
        // Crear un productor que llenará el depósito
        Producer producer = new Producer(DEPOSIT);
        producer.start();

        // Crear varios camiones que transportarán el producto del depósito
        for (int i = 0; i < NUM_OF_TRUCKS; i++) {
            Truck truck = new Truck(DEPOSIT, i + 1);
            truck.start();
        }
    }
}

