import java.net.*;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

// Clase que representa un camión que transporta producto desde el depósito
public class Truck extends Thread {
    private final Deposit dep; // Referencia al depósito
    private final int truckId; // Identificador del camión
    private double totalOfLitersObtained; // Total de litros obtenidos por el camión

    // Constructor que recibe el depósito y el identificador del camión como parámetros
    public Truck(Deposit dep, int truckId) {
        this.dep = dep;
        this.truckId = truckId;
    }

    // Método que define el comportamiento del hilo (camión)
    public void run() {
        int i = 0;

        // Mientras no se alcance el número de cargas por camión
        while (i < Refinery.NUM_OF_LOAD_PER_TRUCK) {
            // Llenar el camión con producto del depósito y registrar la cantidad obtenida
            double receivedLiters = dep.fillTankTruck();
            totalOfLitersObtained += receivedLiters;
            // Imprimir un mensaje indicando la cantidad de litros obtenida por el camión
            System.out.println("Truck " + truckId + " load => " + receivedLiters + " liters");
            i++;
        }

        // Imprimir un mensaje indicando el total de litros obtenidos por el camión y la finalización de la operación de carga
        System.out.println("Truck " + truckId + " => Total Volume Collected = " + totalOfLitersObtained + " Loading operation completed!!");
    }
}

