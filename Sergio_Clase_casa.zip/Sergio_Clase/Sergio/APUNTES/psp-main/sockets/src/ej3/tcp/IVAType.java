package ej3.tcp;

public enum IVAType {
    IGC, ESP, EUR;
}
