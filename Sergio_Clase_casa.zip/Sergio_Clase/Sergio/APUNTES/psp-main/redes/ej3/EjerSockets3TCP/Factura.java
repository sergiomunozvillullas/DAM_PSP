import java.io.Serializable;

@SuppressWarnings("serial")
public class Factura implements Serializable {
    // Atributos de la factura
    private String numeroFactura;
    private int importe;
    private String fechaFactura;
    private String tipoIVA;
    private int IVA;
    private double importeTotal;

    // Constructores
    public Factura() {
        super();
    }

    public Factura(String numeroFactura, int importe, String fechaFactura, String tipoIVA, int IVA, double importeTotal) {
        this.numeroFactura = numeroFactura;
        this.importe = importe;
        this.fechaFactura = fechaFactura;
        this.tipoIVA = tipoIVA;
        this.IVA = IVA;
        this.importeTotal = importeTotal;
    }

    // Métodos getter y setter para los atributos de la factura
    public String getNumeroFactura() {
        return numeroFactura;
    }

    public void setNumeroFactura(String numeroFactura) {
        this.numeroFactura = numeroFactura;
    }

    public int getImporte() {
        return importe;
    }

    public void setImporte(int importe) {
        this.importe = importe;
    }

    public String getFechaFactura() {
        return fechaFactura;
    }

    public void setFechaFactura(String fechaFactura) {
        this.fechaFactura = fechaFactura;
    }

    public String getTipoIVA() {
        return tipoIVA;
    }

    public void setTipoIVA(String tipoIVA) {
        this.tipoIVA = tipoIVA;
    }

    public int getIVA() {
        return IVA;
    }

    public void setIVA(int IVA) {
        this.IVA = IVA;
    }

    public double getImporteTotal() {
        return importeTotal;
    }

    public void setImporteTotal(double importeTotal) {
        this.importeTotal = importeTotal;
    }
}

