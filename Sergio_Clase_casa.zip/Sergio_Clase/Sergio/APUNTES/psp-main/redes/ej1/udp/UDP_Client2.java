import java.io.IOException;
import java.net.*;
import java.nio.ByteBuffer;

public class UDP_Client2 {

    private static final int ARRAY_SIZE = 1024;

    // Método para calcular el factorial de un número
    private static int factorial(int num) {
        if (num == 0) return 1;
        int total = 1;
        for (int i = num; i > 1; i--)
            total *= i;
        return total;
    }

    private static final String serverIp = "localhost";
    private static final int serverPort = 3055;

    public static void main(String[] args) {
        byte[] array = new byte[ARRAY_SIZE];

        try (DatagramSocket datagramSocket = new DatagramSocket()) {
            // Se crea un DatagramPacket con un saludo y se envía al servidor
            DatagramPacket datagramPacket = new DatagramPacket(array, array.length, InetAddress.getByName(serverIp), serverPort);
            datagramSocket.send(datagramPacket);

            // Se espera recibir un número del servidor para calcular su factorial
            datagramSocket.receive(datagramPacket);
            ByteBuffer wrapped = ByteBuffer.wrap(datagramPacket.getData(), 0, datagramPacket.getLength());
            int numToCalculate = wrapped.getInt();

            // Se calcula el factorial del número recibido
            byte[] bytes = ByteBuffer.allocate(4).putInt(factorial(numToCalculate)).array();
            // Se crea un nuevo DatagramPacket con el resultado del cálculo y se envía al servidor
            datagramPacket = new DatagramPacket(bytes, bytes.length, InetAddress.getByName("localhost"), 3055);
            datagramSocket.send(datagramPacket);

        } catch (IOException e) {
            // Si ocurre una excepción de E/S, se lanza una RuntimeException
            throw new RuntimeException(e);
        }
    }
}

