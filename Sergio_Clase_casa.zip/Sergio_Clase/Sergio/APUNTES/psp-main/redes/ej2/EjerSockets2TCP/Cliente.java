import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Random;

public class Cliente {

    public static void main(String[] args) {
        try {
            // Se establece la conexión con el servidor en el puerto 6002
            Socket cliente = new Socket("localhost", 6002);
            // Se crea un flujo de salida para enviar datos al servidor
            ObjectOutputStream salida = new ObjectOutputStream(cliente.getOutputStream());

            // Se crea un objeto de la clase Random para generar números aleatorios
            Random random = new Random();

            // Se crea un array de 10 números aleatorios
            int[] numAleatorios = new int[10];
            for (int i = 0; i < 10; i++) {
                numAleatorios[i] = random.nextInt(101); // Números aleatorios entre 0 y 100
            }

            // Se envía el array de números aleatorios al servidor
            salida.writeObject(numAleatorios);

            // Se cierra la conexión con el servidor
            cliente.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

