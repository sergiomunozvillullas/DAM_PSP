import java.net.*;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Servidor {

    public static void main(String[] args) throws IOException {

        int puerto = 5005; // Puerto en el que el servidor escucha
        double numeroAleatorio = Math.random() * 11; // Generar el número aleatorio entre 0 y 10
        int intentos = 0; // Contador de intentos para cada jugador
        boolean numeroAdivinado = false; // Variable para controlar si el número ha sido adivinado

        System.out.println("Socket servidor");
        ServerSocket servidor = new ServerSocket(puerto);

        // Esperar a que los 4 jugadores se conecten
        Socket cliente1 = servidor.accept();
        Socket cliente2 = servidor.accept();
        Socket cliente3 = servidor.accept();
        Socket cliente4 = servidor.accept();

        // Crear streams de entrada y salida para cada cliente
        DataInputStream in1 = new DataInputStream(cliente1.getInputStream());
        DataOutputStream out1 = new DataOutputStream(cliente1.getOutputStream());
        DataInputStream in2 = new DataInputStream(cliente2.getInputStream());
        DataOutputStream out2 = new DataOutputStream(cliente2.getOutputStream());
        DataInputStream in3 = new DataInputStream(cliente3.getInputStream());
        DataOutputStream out3 = new DataOutputStream(cliente3.getOutputStream());
        DataInputStream in4 = new DataInputStream(cliente4.getInputStream());
        DataOutputStream out4 = new DataOutputStream(cliente4.getOutputStream());

        while (!numeroAdivinado) {
            // Incrementar el contador de intentos
            intentos++;

            // Leer el número enviado por cada cliente
            int numeroRecibido1 = in1.readInt();
            int numeroRecibido2 = in2.readInt();
            int numeroRecibido3 = in3.readInt();
            int numeroRecibido4 = in4.readInt();

            // Después de leer los números recibidos de los clientes, envía las respuestas según corresponda
            if (numeroRecibido1 == numeroAleatorio) {
                out1.writeUTF("¡Felicidades! Adivinaste el número " + numeroAleatorio);
                out2.writeUTF("El jugador 1 ha adivinado el número. Fin del juego.");
                out3.writeUTF("El jugador 1 ha adivinado el número. Fin del juego.");
                out4.writeUTF("El jugador 1 ha adivinado el número. Fin del juego.");
                numeroAdivinado = true;
            } else if (numeroRecibido2 == numeroAleatorio) {
                out2.writeUTF("¡Felicidades! Adivinaste el número " + numeroAleatorio);
                out1.writeUTF("El jugador 2 ha adivinado el número. Fin del juego.");
                out3.writeUTF("El jugador 2 ha adivinado el número. Fin del juego.");
                out4.writeUTF("El jugador 2 ha adivinado el número. Fin del juego.");
                numeroAdivinado = true;
            } else if (numeroRecibido3 == numeroAleatorio) {
                out3.writeUTF("¡Felicidades! Adivinaste el número " + numeroAleatorio);
                out1.writeUTF("El jugador 3 ha adivinado el número. Fin del juego.");
                out2.writeUTF("El jugador 3 ha adivinado el número. Fin del juego.");
                out4.writeUTF("El jugador 3 ha adivinado el número. Fin del juego.");
                numeroAdivinado = true;
            } else if (numeroRecibido4 == numeroAleatorio) {
                out4.writeUTF("¡Felicidades! Adivinaste el número " + numeroAleatorio);
                out1.writeUTF("El jugador 4 ha adivinado el número. Fin del juego.");
                out2.writeUTF("El jugador 4 ha adivinado el número. Fin del juego.");
                out3.writeUTF("El jugador 4 ha adivinado el número. Fin del juego.");
                numeroAdivinado = true;
            } else {
                // Ningún jugador ha adivinado el número, enviar pistas
                if (numeroRecibido1 < numeroAleatorio) {
                    out1.writeUTF("El número enviado es menor que el número a adivinar.");
                } else {
                    out1.writeUTF("El número enviado es mayor que el número a adivinar.");
                }
                if (numeroRecibido2 < numeroAleatorio) {
                    out2.writeUTF("El número enviado es menor que el número a adivinar.");
                } else {
                    out2.writeUTF("El número enviado es mayor que el número a adivinar.");
                }
                if (numeroRecibido3 < numeroAleatorio) {
                    out3.writeUTF("El número enviado es menor que el número a adivinar.");
                } else {
                    out3.writeUTF("El número enviado es mayor que el número a adivinar.");
                }
                if (numeroRecibido4 < numeroAleatorio) {
                    out4.writeUTF("El número enviado es menor que el número a adivinar.");
                } else {
                    out4.writeUTF("El número enviado es mayor que el número a adivinar.");
                }
            }
        }

        // Cerrar conexiones y el servidor
        servidor.close();
        cliente1.close();
        cliente2.close();
        cliente3.close();
        cliente4.close();
    }
}

