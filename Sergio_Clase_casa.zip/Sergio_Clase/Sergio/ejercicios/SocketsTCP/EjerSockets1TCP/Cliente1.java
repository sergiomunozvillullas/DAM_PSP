
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

public class Cliente1 
{

    public static void main(String[] args) 
    {
        String host="localhost";
        int puerto=1111;
        Scanner entrada = new Scanner(System.in);
        int numero = 0;
        
        try 
        {

            Socket Cliente1 = new Socket(host,puerto);
            System.out.println("Inserta un número:");
            numero = entrada.nextInt();
            
            // Enviar el número al servidor
            DataOutputStream out = new DataOutputStream(Cliente1.getOutputStream());
            out.writeInt(numero);
            out.flush();
            
            /*******************************************************************/
            
            DataInputStream in = new DataInputStream(Cliente1.getInputStream());
            int factorial = in.readInt();
            System.out.println("Factorial recibido del servidor: " + factorial);

            Cliente1.close(); //Cierre del socket

        } 
        catch (IOException excepcion) {
            excepcion.printStackTrace();
        }     
        
        
    }//main
    
}//clase
