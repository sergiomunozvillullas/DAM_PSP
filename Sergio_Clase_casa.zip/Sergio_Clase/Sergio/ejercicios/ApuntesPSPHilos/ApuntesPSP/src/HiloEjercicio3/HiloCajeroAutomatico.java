package HiloEjercicio3;

public class HiloCajeroAutomatico 
{

    public static void main(String[] args) 
    {
        CuentaBancaria cuenta = new CuentaBancaria();
        
        Thread padre = new Thread(new HiloIngresarDinero(cuenta,"padre",200));
        Thread hijo1 = new Thread(new HiloIngresarDinero(cuenta,"hijo1",300));
        
        Thread madre = new Thread(new HiloSacarDinero(cuenta,"madre",800));
        Thread hijo2 = new Thread(new HiloSacarDinero(cuenta,"hijo2",800));
        Thread abuelo = new Thread(new HiloSacarDinero(cuenta,"abuelo",500));
        
        
        padre.start();
        madre.start();
        hijo1.start();
        hijo2.start();
        abuelo.start();
    
    } //main   
    
}//clase
