#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
void main()
{
pid_t pid1, pid2;
printf("AAA \n");
pid1 = fork();
if (pid1==0)
{
printf("BBB \n");

}
else
{
wait(0);
 pid2 = fork();
        
        if (pid2 == 0)
        {
            printf("CCC \n");
        }
        else
        {
            wait(0);
        }
}
exit(0);
}



//a) este códgio genera un padre con id 1000 y crea 2 hijos p1001 y p1002
//b) primero el padre imprime AAA, después entra por el else para crear el otro hijo por lo que imprime CCC y hace el exit, asi luego sale BBB y CCC
//No puede imprimir otra salida a no ser que se cambie el código
//c)falta un wait
