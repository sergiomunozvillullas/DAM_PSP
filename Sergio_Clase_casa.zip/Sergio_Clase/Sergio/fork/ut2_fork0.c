#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>

void main() {
  pid_t abuelo, padre, pid_padre, pid_nieto;

  abuelo = fork();

  if (abuelo == -1 ) //Ha ocurrido un error 
  {
    printf("ERROR !!! No se ha podido crear el proceso padre...");
    exit(-1);       
  }
  if (abuelo == 0 )  //Nos encontramos en Proceso padre 
  {        
  
  
  	  padre = fork();

	  if (padre == -1 ) //Ha ocurrido un error 
  	{
  	  printf("ERROR !!! No se ha podido crear el proceso hijo...");
   	 exit(-1);       
  	}
 	 if (padre == 0 )  //Nos encontramos en Proceso hijo 
  	{        

         printf("soy el pid nieto= %d\n",getpid());
         printf("soy el ppid nieto= %d\n",getppid());

  	}
  	else    //Nos encontramos en Proceso padre 
  	{ 

    pid_nieto = wait(NULL); //espera la finalización del proceso nieto
    printf("soy el pid padre= %d\n",getpid());
    printf("soy el ppid padre= %d\n",getppid());   

  	}
//
  }
  	else    //Nos encontramos en Proceso abuelo 
  { 
        	pid_padre = wait(NULL); //espera la finalización del proceso padre
              printf("soy el pid abuelo= %d\n",getpid());
         printf("soy el ppid abuelo= %d\n",getppid()); 
   

  }
   exit(0);
}
