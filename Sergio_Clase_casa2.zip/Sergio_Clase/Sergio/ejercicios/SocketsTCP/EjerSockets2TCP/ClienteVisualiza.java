package EjerSockets2TCP;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Random;

public class ClienteVisualiza 
{

     public static void main(String[] args) throws ClassNotFoundException {
        try {
            Socket cliente = new Socket("localhost", 6002);
            ObjectInputStream entrada = new ObjectInputStream(cliente.getInputStream());
       
            int[] resultados = (int[]) entrada.readObject();
            System.out.println("Suma de los elementos del array: " + resultados[0]);
            System.out.println("Número mayor del array: " + resultados[1]);
            System.out.println("Número menor del array: " + resultados[2]);
            
            cliente.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}//class