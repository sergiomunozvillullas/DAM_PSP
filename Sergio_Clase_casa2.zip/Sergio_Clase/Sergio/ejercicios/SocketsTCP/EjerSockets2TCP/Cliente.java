package EjerSockets2TCP;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Random;

public class Cliente
{
    public static void main(String[] args) {
        try {
            Socket cliente = new Socket("localhost", 6002);
            ObjectOutputStream salida = new ObjectOutputStream(cliente.getOutputStream());
            Random random = new Random();
       
            // Crear el array aleatorio
            int[] numAleatorios = new int[10];
            for (int i = 0; i < 10; i++) 
            {
                numAleatorios[i] = random.nextInt(101);
            }
            salida.writeObject(numAleatorios);
            cliente.close();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}//class
