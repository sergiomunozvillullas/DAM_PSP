package HiloEjercicio3;

public class CuentaBancaria 
{
    
    // Saldo inicial de la cuenta
    private int saldo = 1000;
    private static final Object monitor = new Object();

    public void sacarDinero(String nombre, int importe) 
    {
        synchronized (monitor) 
        {
                if (importe > saldo) 
                {
                    System.out.println(nombre + " ha intentado sacar " + importe + ". NO HAY SALDO SUFICIENTE");
                } 
                else 
                {
                    saldo -= importe;
                    System.out.println(nombre + " ha sacado " + importe);

                    try 
                    {
                        Thread.sleep(1000); // Retraso de 1 segundo
                    } 
                    catch (InterruptedException e) 
                    {
                        e.printStackTrace();
                    }
                    System.out.println("Saldo actual de la cuenta: " + saldo);
                }
        }        
    }

    /*****************************************************************************/

    public void ingresarDinero(String nombre, int importe) 
    {
        synchronized (monitor) 
        {
            saldo += importe;
            System.out.println(nombre + " ha ingresado " + importe);

            try 
            {
                Thread.sleep(1000); // Retraso de 1 segundo
            } 
            catch (InterruptedException e) 
            {
                e.printStackTrace();
            }
            System.out.println("Saldo actual de la cuenta: " + saldo);
        }
    }
    
}
