package HiloEjercicio1;

public class HiloParImpar implements Runnable
{

    private int tipo;
    private static final Object monitor = new Object();
    
    public HiloParImpar(int tipo)
    {
        this.tipo = tipo;
    }

    /**********************************************************************/
    
    public void run()
    {
        synchronized (monitor) 
        {
            
            switch(tipo)
            {
                case 1:
                    for(int i=0 ;i<=100 ;i++)
                    {
                        if(i%2==0)
                        {
                            System.out.println("Hilo xx generando número par : "+i);
                        }    
                    }
                case 2:
                    for(int i=101 ;i<=200 ;i++)
                    {
                        if(i%2!=0)
                        {
                            System.out.println("Hilo yy generando número imparpar : "+i);
                        }    
                    }
            }   
        }
    }        
    
    
}//clase
