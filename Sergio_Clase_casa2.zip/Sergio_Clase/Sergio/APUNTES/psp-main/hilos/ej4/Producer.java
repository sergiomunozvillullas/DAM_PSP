import java.util.Random;

// Clase que representa un productor que llena un depósito
public class Producer extends Thread {
    private final Deposit deposit; // Referencia al depósito que será llenado
    private final Random random = new Random(); // Generador de números aleatorios

    // Constructor que recibe el depósito como parámetro
    public Producer(Deposit deposit) {
        this.deposit = deposit;
    }

    // Método que define el comportamiento del hilo
    public void run() {
        // Itera sobre el número de cargas a realizar
        for (int i = 0; i < Refinery.NUM_OF_LOAD; i++){
            // Llena el depósito con una cantidad aleatoria de litros
            deposit.producerFillsDeposit(generateRandomNumber());
            try {
                sleep(1000); // Espera 1 segundo entre cargas
            } catch (InterruptedException e) {
                // Si ocurre una interrupción durante la espera, lanza una excepción
                throw new RuntimeException(e);
            }
        }
    }

    // Método que genera un número aleatorio de litros a cargar en el depósito
    public double generateRandomNumber(){
        // Genera un número aleatorio entre 0.0 (incluido) y 1.0 (excluido),
        // luego lo multiplica por el límite de litros por carga y le suma 1
        // para asegurarse de que esté dentro del rango deseado.
        return random.nextDouble() * Refinery.LITERS_PER_CHARGE_RANDOM_LIMIT + 1;
    }
}

