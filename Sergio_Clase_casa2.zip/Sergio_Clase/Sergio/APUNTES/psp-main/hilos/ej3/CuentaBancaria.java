import java.net.*;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

// Clase que representa una cuenta bancaria
class CuentaBancaria {
    private int saldo = 1000; // Saldo inicial de la cuenta

    // Método sincronizado para sacar dinero de la cuenta
    public synchronized void sacarDinero(String nombre, int importe) {
        // Verificar si hay saldo suficiente para realizar la operación
        if (saldo >= importe) {
            saldo -= importe; // Restar el importe del saldo
            System.out.println(nombre + " sacó de la cuenta " + importe + "€");
        } else {
            // Si no hay saldo suficiente, imprimir un mensaje de error
            System.out.println(nombre + " no puede sacar " + importe + "€ -> NO HAY SALDO SUFICIENTE");
        }
        // Imprimir el saldo actual de la cuenta
        System.out.println("Saldo actual cuenta= " + saldo + "€");

        // Simular una pequeña pausa para hacer la ejecución más lenta y visible
        try {
            Thread.sleep(1000); // Pausa de 1 segundo
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    // Método sincronizado para ingresar dinero en la cuenta
    public synchronized void ingresarDinero(String nombre, int importe) {
        saldo += importe; // Sumar el importe al saldo
        System.out.println(nombre + " ingresó en la cuenta " + importe + "€");
        // Imprimir el saldo actual de la cuenta
        System.out.println("Saldo actual cuenta= " + saldo + "€");

        // Simular una pequeña pausa para hacer la ejecución más lenta y visible
        try {
            Thread.sleep(1000); // Pausa de 1 segundo
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}

