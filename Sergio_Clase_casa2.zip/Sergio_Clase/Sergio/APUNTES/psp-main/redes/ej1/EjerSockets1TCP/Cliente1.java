import java.net.*;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

// Importación del paquete Scanner para la entrada del usuario

public class Cliente1 {

    public static void main(String[] args) {

        // Definición de variables para la conexión
        String host = "localhost"; // Dirección del servidor
        int puerto = 1111; // Puerto en el que el servidor está escuchando

        // Creación de un objeto Scanner para leer la entrada del usuario
        Scanner entrada = new Scanner(System.in);

        // Variable para almacenar el número proporcionado por el usuario
        int numero = 0;
        int numero2= 0;

        try {

            // Establecer conexión con el servidor
            Socket Cliente1 = new Socket(host, puerto);

            // Solicitar al usuario que ingrese un número
            System.out.println("Inserta un número:");
            numero = entrada.nextInt();
            

            // Enviar el número al servidor a través de un DataOutputStream
            DataOutputStream out = new DataOutputStream(Cliente1.getOutputStream());
            out.writeInt(numero); // Escribir el número en el flujo de salida
            
            /* ENVIAR OTRO NUMERO
            // Solicitar al usuario que ingrese un número
            System.out.println("Inserta un número:");
            numero2 = entrada.nextInt();
            
            out.writeInt(numero2); // Escribir el número en el flujo de salida
            
            */
            
            out.flush(); // Limpiar el flujo de salida

            /*******************************************************************/

            // Recibir la respuesta del servidor (el factorial calculado)
            DataInputStream in = new DataInputStream(Cliente1.getInputStream());
            int factorial = in.readInt(); // Leer el factorial del flujo de entrada

            // Mostrar el factorial recibido del servidor en la consola
            System.out.println("Factorial recibido del servidor: " + factorial);

            // Cerrar la conexión con el servidor
            Cliente1.close();

        } catch (IOException excepcion) {
            // Manejar cualquier excepción que ocurra durante la ejecución e imprimir el rastreo de la pila
            excepcion.printStackTrace();
        }
    } // Fin del método main
} // Fin de la clase Cliente1

