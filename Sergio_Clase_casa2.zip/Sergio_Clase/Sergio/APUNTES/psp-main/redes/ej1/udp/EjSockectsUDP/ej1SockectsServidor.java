
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Sara
 */
public class ej1SockectsServidor {
    public static void main(String[] args) {
        final int puerto = 5000;
        try (DatagramSocket servidor = new DatagramSocket(puerto)) {
            byte[] buffer = new byte[1024];
            DatagramPacket entrada = new DatagramPacket(buffer, buffer.length);
            
            // Recibir número del cliente 1
            servidor.receive(entrada);
            String numeroBuffer = new String(entrada.getData(), 0, entrada.getLength()).trim();
            System.out.println("Número recibido del cliente 1: " + numeroBuffer);
            
            // Enviar número al cliente 2
            InetAddress direccionCliente2 = InetAddress.getLocalHost();
            int puertoC2 = 5001;
            DatagramPacket salida = new DatagramPacket(buffer, buffer.length, direccionCliente2, puertoC2);
            servidor.send(salida);
            
            // Recibir factorial del cliente 2
            DatagramPacket entradaC2 = new DatagramPacket(buffer, buffer.length);
            servidor.receive(entradaC2);
            String factorialBuffer = new String(entradaC2.getData(), 0, entradaC2.getLength()).trim();
            System.out.println("Factorial recibido del cliente 2: " + factorialBuffer);
            
            // Enviar factorial al cliente 1
            InetAddress direccionCliente1 = entrada.getAddress();
            int client1Port = entrada.getPort();
            byte[] bufferC2 = factorialBuffer.getBytes();
            System.out.println(factorialBuffer);
            DatagramPacket salidaC1 = new DatagramPacket(bufferC2, bufferC2.length, direccionCliente1, client1Port);
            servidor.send(salidaC1);
        } catch (IOException ex) {
            Logger.getLogger(ej1SockectsServidor.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}

