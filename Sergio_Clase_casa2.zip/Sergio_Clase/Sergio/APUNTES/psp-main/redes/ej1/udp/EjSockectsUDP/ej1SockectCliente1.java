
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Sara
 */
public class ej1SockectCliente1 {
    public static void main(String[] args) {
        final int puerto = 5000;
        try (DatagramSocket cliente1 = new DatagramSocket()){
            byte[] buffer = new byte[1024];
            InetAddress direccion = InetAddress.getLocalHost();
            
            // Pedir número por pantalla
            Scanner entradaS = new Scanner(System.in);
            System.out.println("Inserta un número:");
            int numero = entradaS.nextInt();
            
            // Pasar el número a String para introducirlo en el buffer
            String numeroBuffer = String.valueOf(numero);
            buffer = numeroBuffer.getBytes();
            
            // Crear un paquete de salida y enviarlo
            DatagramPacket salida = new DatagramPacket(buffer, buffer.length, direccion, puerto);
            cliente1.send(salida);
            
            // Recibir el factorial enviado por el servidor
            byte[] buffer2 = new byte[1024];
            DatagramPacket entrada = new DatagramPacket(buffer2, buffer2.length);
            cliente1.receive(entrada);
            String factorialBuffer = new String(entrada.getData()).trim();
            int factorial = Integer.parseInt(factorialBuffer);
            System.out.println("El factorial de " + numero + " es " + factorial);
            
            // Cerrar el socket del cliente
            cliente1.close();
        } catch (SocketException | UnknownHostException ex) {
            Logger.getLogger(ej1SockectCliente1.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(ej1SockectCliente1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}

