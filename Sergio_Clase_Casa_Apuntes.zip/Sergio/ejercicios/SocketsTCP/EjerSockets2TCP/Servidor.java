package EjerSockets2TCP;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

public class Servidor{
    public static void main(String[] args) throws ClassNotFoundException {
        try {
            ServerSocket servidor = new ServerSocket(6002);
            Socket cliente1 = servidor.accept();
            Socket visualizar = servidor.accept();

            ObjectInputStream entradaCliente1 = new ObjectInputStream(cliente1.getInputStream());
            ObjectOutputStream salidaVisualizar = new ObjectOutputStream(visualizar.getOutputStream());

            // Leer array del cliente1
            int[] array = (int[]) entradaCliente1.readObject();
            System.out.println("Array recibido del Cliente1: ");
            int suma = 0;
            int mayor = array[0]; // Corrección aquí
            int menor = array[0]; // Corrección aquí
            for (int i = 0; i < array.length; i++) { // Corrección aquí
                System.out.println(array[i]);
                suma += array[i];
                if (mayor < array[i]) {
                    mayor = array[i];
                }
                if (array[i] < menor) {
                    menor = array[i];
                }
            }
            int[] resultados = {suma, mayor, menor};
            salidaVisualizar.writeObject(resultados);

            servidor.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
