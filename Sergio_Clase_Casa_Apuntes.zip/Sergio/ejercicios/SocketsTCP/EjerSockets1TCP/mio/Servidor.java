import java.net.*;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;
public class Servidor 
{

    public static void main(String[] args) 
    {
        int puerto=1111;
        
        try 
        {
            ServerSocket Servidor = new ServerSocket(puerto); //socket servidor asociado puerto
            System.out.println("Socket servidor");
            System.out.println(" ");
            Socket cliente1= Servidor.accept();
            
            // Recibir el número cliente1
            DataInputStream in = new DataInputStream(cliente1.getInputStream());
            int numeroRecibido = in.readInt();
            System.out.println("Cliente 1 conectado");
            System.out.println("Número recibido: " + numeroRecibido);
            System.out.println(" ");
 
        /***********************************************************************/   
            
            // Enviar el número cliente2
            Socket cliente2 = Servidor.accept();
            DataOutputStream out = new DataOutputStream(cliente2.getOutputStream());//flujo salida a cliente2
            out.writeInt(numeroRecibido);
            out.flush();
            System.out.println("Número enviado al Cliente 2");
            
            // Recibir el factorial cliente2
            DataInputStream in2 = new DataInputStream(cliente2.getInputStream());
            int factorialRecibido = in2.readInt();
            System.out.println(" ");
            System.out.println("Cliente 2 conectado");
            System.out.println("Factorial recibido" );            
            
        /***********************************************************************/
        
            cliente1= Servidor.accept();
            DataOutputStream out1 = new DataOutputStream(cliente1.getOutputStream());//flujo salida a cliente2
            out.writeInt(factorialRecibido);
            out.flush();
            System.out.println(" ");
            System.out.println("Número enviado al Cliente 1 ");
            
            Servidor.close();
        } 
        catch (IOException excepcion) {
            excepcion.printStackTrace();
        }

    }//main

}//clase
