package HiloEjercicio2;

public class HiloSumasRestas implements Runnable {

    private static int numero = 1000;
    private int numveces = 0;
    private String operacion = "+";
    private static final Object monitor = new Object();

    public HiloSumasRestas(int numveces, String operacion) {
        this.numveces = numveces;
        this.operacion = operacion;
    }

    public void run() {
        synchronized (monitor) {
            if (operacion.equals("+")) {
                incrementar(numveces);
            }

            if (operacion.equals("-")) {
                decrementar(numveces);
            }
            System.out.println("Resultado final: " + numero);
        }
    }

    public static void incrementar(int numveces) {
        for (int i = 0; i < numveces; i++) {
            numero++;
        }
    }

    public static void decrementar(int numveces) {
        for (int i = 0; i < numveces; i++) {
            numero--;
        }
    }
}
