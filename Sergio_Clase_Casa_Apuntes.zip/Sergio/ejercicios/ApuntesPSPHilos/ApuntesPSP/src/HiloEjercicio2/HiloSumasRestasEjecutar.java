package HiloEjercicio2;

public class HiloSumasRestasEjecutar 
{

    public static void main(String[] args) 
    {
       
        Thread hilo1 = new Thread(new HiloSumasRestas(100, "+"));
        Thread hilo2 = new Thread(new HiloSumasRestas(100, "-"));
        Thread hilo3 = new Thread(new HiloSumasRestas(1, "+"));
        Thread hilo4 = new Thread(new HiloSumasRestas(1, "-"));
        
        hilo1.start();
        hilo2.start();
        hilo3.start();
        hilo4.start();
        
                
    }//main
    
}//clase
