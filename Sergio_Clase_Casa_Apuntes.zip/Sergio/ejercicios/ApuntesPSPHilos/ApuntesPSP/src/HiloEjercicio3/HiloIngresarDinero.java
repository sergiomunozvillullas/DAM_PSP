package HiloEjercicio3;

public class HiloIngresarDinero implements Runnable 
{
     
    private CuentaBancaria cuenta; 
    private String nombre; 
    private int cantidad; 
 
    // Constructor de la clase 
    public HiloIngresarDinero(CuentaBancaria micuenta, String nombre, int cantidad) 
    { 
        this.cuenta = micuenta;
        this.nombre = nombre;
        this.cantidad = cantidad;
    } 
 
    public void run() 
    {  
        cuenta.ingresarDinero(nombre, cantidad);
    } 
    
}
