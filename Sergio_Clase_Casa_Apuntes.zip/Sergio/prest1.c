#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h> 
#include <time.h>
#include <string.h>
#include <math.h>


//P1-P2-P3
//p1 a p2    p2 a p3 

void main() {
    // Declaración de tuberías
    int fd[2], fd2[2];
    int numero;
    double numeross2;
    char buffer[5], num1;

    // Declaración de identificadores de procesos
    pid_t pid, pid2;

    // Creamos el pipe
    pipe(fd); 

    // Se crea un proceso hijo
    pid = fork();

    if (pid == 0) {
        // Código del primer hijo
        pipe(fd2); 
        pid2 = fork();

        if (pid2 == 0) {
            // Código del segundo hijo
            close(fd2[1]);
            double cantNum2;
            read(fd2[0], &cantNum2, sizeof(cantNum2));
 		printf("Cuota resultante: %f \n", cantNum2);

 

        }
        else {
            // Código del primer hijo
            close(fd[1]); // Cierra el descriptor de escritura
            int primernum, numero3,plazo;
            double primernum2,intMensual,total,potencia;
            read(fd[0], &primernum, sizeof(primernum));
	    read(fd[0], &primernum2, sizeof(primernum2));
	     //printf("\n");
	     //printf("num1: %d \n", primernum);
	     //printf("num2: %f \n", primernum2);
	     //printf("\n");
	     
	     printf("¿Periodo de amortización en años?:");
        	scanf("%d", &numero3);
	     //printf("num3: %d \n", numero3);
	     //printf("\n");
            close(fd2[0]);
            
            
            plazo=numero3*12;
            intMensual=(primernum2/(12*100));
            potencia= pow ((1+intMensual),plazo);
            total= (primernum*intMensual*potencia)/(potencia-1);
            
            
            //printf("intMen: %f \n", intMensual);
            write(fd2[1], &total, sizeof(total));
	
            

            wait(NULL); // Espera al tercer proceso
        }
    }
    else {
        // Código del proceso padre
        
        printf("¿Importe del préstamo?: ");
        scanf("%d", &numero);
        close(fd[0]); // Cierra el descriptor de lectura
        write(fd[1], &numero, sizeof(numero));
        
        printf("¿Tipo de interés anual?: ");
        scanf("%lf", &numeross2);

        write(fd[1], &numeross2, sizeof(numeross2));
        wait(NULL);
    }
}


