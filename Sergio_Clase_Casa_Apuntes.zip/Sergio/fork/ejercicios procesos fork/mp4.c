#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
void main()
{
//escribe CCC en el proceso 1
printf("CCC \n");
//crea proceso hijo
if (fork()!=0)
{
//si es el padre
printf("AAA \n");
//con el wait corregimos el código
 wait(0);
}
//sino escribe BBB (proceso hijo)es
 else printf("BBB \n");

exit(0);
}




//a) padre(mp4) PID 1000 PPID ?
//   hijo       PID 1001 PPID 1000


//b) la salida genera:
// CCC
// AAA
// BBB pero esta parte lo imprime en otra ejecución

//si puede variar según que proceso se ejecute primero


//c)
