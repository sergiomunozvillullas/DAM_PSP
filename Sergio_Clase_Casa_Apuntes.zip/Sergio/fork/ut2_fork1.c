#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>

//definir variable tipo entero = 100
//el hijo va a incrementar a la variable +1 y lo va a mostrar
//el padre va a decrementar a la variable -1 y lo va a mostrar

//ABUELO-PADRE-NIETO
void main() {

  pid_t var1;
  int var100 = 100;
  
  var1=fork();
  var100++;
  var2=fork();
 
  if (var1==0){
  	var100++;
  	printf("la varibale desde el proceso 2 (hijo) es = %d\n",var100);

  }else{
    wait(NULL);
    int PEPE=666;
    var100--;
	printf("la varibale desde el proceso 1 (padre) es = %d\n",var100);
  }
 
   exit(0);
}
