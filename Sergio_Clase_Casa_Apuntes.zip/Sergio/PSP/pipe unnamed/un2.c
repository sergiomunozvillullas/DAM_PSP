
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

int factorial(int n) {
    if (n == 0 || n == 1) {
        return 1;
    } else {
        return n * factorial(n - 1);
    }
}

int main() {
    // Crear el pipe FIFO2
    mkfifo("FIFO1", 0666);

    int fd2 = open("FIFO1", O_RDONLY);

    // Leer el número de PIPE02
    int numero;
    read(fd2, &numero, sizeof(numero));

    // Calcular el factorial del número
    int resultado = factorial(numero);

    printf("fifo22 calcula el factorial de %d y escribe el resultado en PIPE02\n", numero);

    // Escribir el resultado en PIPE02 (para simular el envío de vuelta)
    write(fd2, &resultado, sizeof(resultado));



    return 0;
}
