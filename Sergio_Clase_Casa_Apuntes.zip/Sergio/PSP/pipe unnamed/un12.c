// fifo21.c
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

int main() {
    // Crear el pipe PIPE02
    mkfifo("PIPE02", 0666);

    // Abrir PIPE02 en modo escritura
    int fd = open("PIPE02", O_WRONLY);

    // Generar un número aleatorio entre 0 y 10
    int numero = rand() % 11;

    // Escribir el número en PIPE02
    write(fd, &numero, sizeof(numero));

    // Cierre del descriptor
    close(fd);

    // Mostrar por pantalla el número generado
    printf("fifo21 generó el número %d en PIPE02\n", numero);

    // Abrir PIPE02 en modo lectura para esperar el resultado
    fd = open("PIPE02", O_RDONLY);

    // Leer el resultado del pipe
    int resultado;
    read(fd, &resultado, sizeof(resultado));

    // Mostrar por pantalla el resultado del cálculo
    printf("fifo21 recibe el resultado del cálculo: %d\n", resultado);

    // Cierre del descriptor
    close(fd);

    // Eliminar el pipe PIPE02
    unlink("PIPE02");

    return 0;
}

