

public class Camion extends Thread 
{
    private Deposito deposito; 
    private int n;

    public Camion(Deposito dep, int n) 
    { 
        deposito = dep;
        this.n = n;
    }

    public void run() 
    {
        for (int i = 0; i < 5; i++) 
        {
            int carga = deposito.get();
            System.out.println("Camión " + n + " carga: " + carga + " litros.");
        }
    }
}
