

import java.util.Random;

public class Prod extends Thread 
{
    private Deposito deposito; 
    private int n;

    public Prod(Deposito dep) 
    {
        deposito = dep;
    }

    public void run() 
    {
        Random random = new Random();
        for (int i = 0; i < 15; i++) 
        {
            int carga = random.nextInt(1001);
            deposito.put(carga);


            try 
            {
                sleep(100);
            } 
            catch (InterruptedException e) 
            {
                e.printStackTrace();
            }
            
        }
    }
}
