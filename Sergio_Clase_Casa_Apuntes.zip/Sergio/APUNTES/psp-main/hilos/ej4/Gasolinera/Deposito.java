
import java.util.Random;

public class Deposito 
{
    private int gasolina;
    private boolean llenando = false;
    private Random random = new Random();

    public synchronized int get() 
    {
        while (!llenando) 
        {
            try 
            {
                wait();
            } 
            catch (InterruptedException e) 
            {
                Thread.currentThread().interrupt();
            }
        }

        llenando = false;
        notify(); 
        return gasolina;
    }
    
    public synchronized void put(int valor) 
    {
        while (llenando) 
        {
            try 
            {
                wait();
            } 
            catch (InterruptedException e) 
            {
                Thread.currentThread().interrupt();
            }
        }

        gasolina = valor;
        llenando = true;
        System.out.println("Productor llenó el depósito con: " + valor + " litros.");
        notify();  
    }

}
