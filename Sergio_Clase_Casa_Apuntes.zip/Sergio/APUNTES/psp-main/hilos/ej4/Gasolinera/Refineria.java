
public class Refineria 
{
    public static void main(String[] args) 
    {
        Deposito deposito = new Deposito();

        Prod prod = new Prod(deposito);
        Camion cons1 = new Camion(deposito, 1);
        Camion cons2 = new Camion(deposito, 2);
        Camion cons3 = new Camion(deposito, 3);

        prod.start();
        cons1.start();
        cons2.start();
        cons3.start();

    }
}
