//Clase consumidor: recoge número de la cola con método "get"
import java.util.Random;

public class Camion extends Thread {
    private Deposito dep;
    private int n;


    //Constructor recibe la cola y un id para el hilo consumidor
    public Camion(Deposito dep, int n) {
        this.dep = dep;
        this.n = n;
    }

    public void run() {
     Random random = new Random();
        
        // Generar un número aleatorio entre 0 y 99
  double valor = 0;
  double total=0;
    
        for (int i = 1; i <= 5; i++) {
            valor = dep.llenarDepositoCamion(); //recoge el n�mero
            System.out.println("Camion " + n
                               + " carga: " + valor + " litros");
                               total=total+valor;
        }
         System.out.println("Camion " + n + " -TOTAL: " + total + " FIN");
    }
}
