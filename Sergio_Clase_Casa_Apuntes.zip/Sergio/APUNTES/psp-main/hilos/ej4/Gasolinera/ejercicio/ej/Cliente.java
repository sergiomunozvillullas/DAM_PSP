//Clase consumidor: recoge número de la cola con método "get"
import java.util.Random;

public class Cliente extends Thread {
    private Gasolinera gas;
    private int n;


    //Constructor recibe la cola y un id para el hilo consumidor
    public Cliente(Gasolinera gas, int n) {
        this.gas = gas;
        this.n = n;
    }

    public void run() {
    
    
    
    
    
    gas.entrarSurtidor();

    System.out.println("Cliente " + n + "esta repostando");
                   
    gas.salirSurtidor();  
    }
    
    
    
    /*
     Random random = new Random();
        
        // Generar un número aleatorio entre 0 y 99
  double valor = 0;
  double total=0;
    
        for (int i = 1; i <= 5; i++) {
            gas.entrarSurtidor(); //recoge el n�mero
            System.out.println("Cliente " + n
                               + " carga: " + valor + " litros");
                               total=total+valor;
        }
         System.out.println("Camion " + n + " -TOTAL: " + total + " FIN");
         
         */
    
}
