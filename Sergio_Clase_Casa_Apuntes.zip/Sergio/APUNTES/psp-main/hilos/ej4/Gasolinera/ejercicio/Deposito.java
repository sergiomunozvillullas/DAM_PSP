import java.util.Random;

public class Deposito {
private double litrosdeposito;
private boolean disponible = false; 

    
    public synchronized double llenarDepositoCamion() {
         // Queda a la espera hasta que la cola se llene ("mientras cola vacía espero en wait()")
    	  while (!disponible) {
    	    try {
    	          wait();
    	    } catch (InterruptedException e) { }
    	  }
    	  //Una vez hay valor disponible se devuelve

    	  disponible = false;
    	  notify();
    	  return litrosdeposito;
    	}


    public synchronized void prodLlenaDep(double valor) {
     // Queda a la espera hasta que la cola se vacíe ("mientras haya datos en la cola espero en wait()")
    	  while (disponible){
    	    try {
    	          wait();
    	    } catch (InterruptedException e) { }
    	  }

    	  litrosdeposito = valor;
    	  disponible = true;
            System.out.println(" Productor llena el deposito con: " + valor);
    	  notifyAll();
    	}


    
}
