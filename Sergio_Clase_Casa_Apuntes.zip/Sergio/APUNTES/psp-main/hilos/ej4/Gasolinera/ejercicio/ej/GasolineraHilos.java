
public class GasolineraHilos {
    public static void main(String[] args) {
      
    Gasolinera gas = new Gasolinera();
		//10 coches 
	Cliente cons1 = new Cliente(gas, 1);
	Cliente cons2 = new Cliente(gas, 2);
	Cliente cons3 = new Cliente(gas, 3);
	Cliente cons4 = new Cliente(gas, 4);
	Cliente cons5 = new Cliente(gas, 5);
	Cliente cons6 = new Cliente(gas, 6);
	Cliente cons7 = new Cliente(gas, 7);
	Cliente cons8 = new Cliente(gas, 8);
	Cliente cons9 = new Cliente(gas, 9);
	Cliente cons10 = new Cliente(gas, 10);
	
	cons1.start();
	cons2.start();
	cons3.start();
	cons4.start();
	cons5.start();
	cons6.start();
	cons7.start();
	cons8.start();
	cons9.start();
	cons10.start();

  }
}

