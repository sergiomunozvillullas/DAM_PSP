//Clase Productor: produce números y los pone en la cola usando método "put"
import java.util.Random;
public class Productor extends Thread {
    private Deposito dep;


    //Constructor recibe la cola y un id para el hilo prodcutor
    public Productor(Deposito dep) {
        this.dep = dep;
    }

    public void run() {
     Random random = new Random();
	while(true){
          double valor = random.nextDouble() * 10.0; // Generar un nuevo valor aleatorio en cada iteración
            dep.prodLlenaDep(valor); //escribe el número en la coala
             System.out.println(" Productor llena el deposito con: " + valor);
            try {
                sleep(1000);
            } catch (InterruptedException e) { }			
			
        }
    }
}


