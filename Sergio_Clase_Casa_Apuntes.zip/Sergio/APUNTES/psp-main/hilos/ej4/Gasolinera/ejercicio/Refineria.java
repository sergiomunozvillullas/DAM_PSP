public class Refineria {
  public static void main(String[] args) {  
    
    Deposito dep = new Deposito();
	
    Productor prod = new Productor(dep);	
	Camion cons1 = new Camion(dep, 1);
	Camion cons2 = new Camion(dep, 2);
	Camion cons3 = new Camion(dep, 3);
	
    prod.start();
	cons1.start();
	  cons2.start();
	  cons3.start();

  }
}
