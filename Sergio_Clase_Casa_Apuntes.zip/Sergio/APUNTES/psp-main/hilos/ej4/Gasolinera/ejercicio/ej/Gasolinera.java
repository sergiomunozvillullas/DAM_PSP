import java.util.Random;
import java.lang.Thread;
public class Gasolinera {
private int surtidor = 3;

    
    public synchronized void entrarSurtidor() {
         // Queda a la espera hasta que la cola se llene ("mientras cola vacía espero en wait()")

    	  //Una vez hay valor disponible se devuelve
    	  while(surtidor<=0){
                try {
                wait();
                Thread.sleep(5000);
            } catch (InterruptedException e) { }
            }
    	  surtidor--;
    	  System.out.println("Surtidores disponibles. " + surtidor);
    	  notify();
    	
    	}


    public synchronized void salirSurtidor() {
     // Queda a la espera hasta que la cola se vacíe ("mientras haya datos en la cola espero en wait()")

    	  surtidor++;
           
    	  notifyAll();
    	}


    
}
