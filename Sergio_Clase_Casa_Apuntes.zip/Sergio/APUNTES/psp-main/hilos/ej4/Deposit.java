import java.net.*;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

// Clase que representa un depósito de almacenamiento
public class Deposit {
    private double liters; // Litros almacenados en el depósito
    private boolean isFull = false; // Indica si el depósito está lleno

    // Método que simula el llenado de un camión cisterna desde el depósito
    public synchronized double fillTankTruck() {
        // Mientras el depósito no esté lleno, esperar
        while (!isFull) {
            try {
                wait(); // Esperar hasta que el depósito esté lleno
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt(); // Restaurar la interrupción
                throw new RuntimeException(e); // Lanzar una excepción en caso de interrupción
            }
        }
        // Si el depósito está lleno, almacenar el valor de litros en una variable temporal
        double toReturn = liters;
        liters = 0; // Reiniciar el depósito a cero
        isFull = false; // El depósito ya no está lleno
        notifyAll(); // Notificar a todos los hilos que están esperando
        return toReturn; // Devolver los litros almacenados previamente
    }

    // Método que simula el llenado del depósito por parte del productor
    public synchronized void producerFillsDeposit(double liters) {
        // Mientras el depósito esté lleno, esperar
        while (isFull) {
            try {
                wait(); // Esperar hasta que el depósito no esté lleno
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt(); // Restaurar la interrupción
                throw new RuntimeException(e); // Lanzar una excepción en caso de interrupción
            }
        }
        // Almacenar los litros suministrados por el productor en el depósito
        this.liters = liters;
        System.out.println("Producer fills the tank with " + liters); // Imprimir un mensaje indicando la cantidad de litros suministrada
        isFull = true; // Marcar el depósito como lleno
        notifyAll(); // Notificar a todos los hilos que están esperando
    }
}

