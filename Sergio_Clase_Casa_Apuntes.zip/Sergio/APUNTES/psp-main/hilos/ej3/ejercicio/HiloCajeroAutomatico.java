// Clase Principal
public class HiloCajeroAutomatico {
public static void main(String[] args)
{
// Código de la clase principal


CuentaBancaria cue = new CuentaBancaria();

HiloIngresarDinero ing1 = new HiloIngresarDinero(cue,"padre",100);
HiloSacarDinero sac1 = new HiloSacarDinero(cue,"madre",500);

ing1.start();
sac1.start();



}
}
