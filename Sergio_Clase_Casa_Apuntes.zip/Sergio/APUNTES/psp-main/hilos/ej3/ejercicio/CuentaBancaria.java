// Clase CuentaBancaria
// Definición de la cuenta con un saldo inicial y de las operaciones para
//ingresar dinero (método ingresarDinero) y sacar dinero (método sacarDinero) de // la cuenta
class CuentaBancaria {
//Saldo inicial de la cuenta
int saldo = 200;
//método sacarDinero:
// nombre -> persona que realiza la operación
//importe -> cantidad a retirar
public synchronized void sacarDinero (String nombre, int importe)
{
//Después de la operación dormir el hilo

	try {
	
	Thread.sleep(1000);
	}
	catch (InterruptedException e) {
	e.printStackTrace();
	}
	if(importe>saldo){
		System.out.println(nombre + " no puede sacar " + importe + "€  -> NO HAY SALDO");
	}else{
	System.out.println(nombre + " saca " + importe + "€");
	saldo=saldo-importe;
	System.out.println("Saldo actual de la cuenta= " + saldo + "€");
	}
	System.out.println("Saldo actual de la cuenta= " + saldo + "€");
}
//método ingresarDinero
//nombre -> persona que realiza la operación
//importe -> cantidad a retirar
public synchronized void ingresarDinero (String nombre, int importe)
{
	//Después de la operación dormir el hilo
	try {
	
	Thread.sleep(1000);
	}
	catch (InterruptedException e) {
	e.printStackTrace();
	}
	System.out.println(nombre + " ingresa " + importe + "€");
	saldo=saldo+importe;
	System.out.println("Saldo actual de la cuenta= " + saldo + "€");
}
}
