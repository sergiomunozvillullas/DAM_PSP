import java.net.*;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

// Clase que representa el programa principal del cajero automático
public class HiloCajeroAutomatico {
    public static void main(String[] args) {
        // Crear una instancia de la cuenta bancaria compartida
        CuentaBancaria cuentaCompartida = new CuentaBancaria();

        // Crear varios hilos que realizan operaciones en la cuenta bancaria
        Thread padre = new HiloSacarDinero(cuentaCompartida, "Padre", 200); // Hilo que saca dinero
        Thread madre = new HiloSacarDinero(cuentaCompartida, "Madre", 400); // Otro hilo que saca dinero
        Thread hijo1 = new HiloIngresarDinero(cuentaCompartida, "Hijo1", 300); // Hilo que ingresa dinero
        Thread hijo2 = new HiloSacarDinero(cuentaCompartida, "Hijo2", 800); // Otro hilo que saca dinero
        Thread abuelo = new HiloSacarDinero(cuentaCompartida, "Abuelo", 600); // Otro hilo que saca dinero

        // Iniciar todos los hilos
        padre.start();
        madre.start();
        hijo1.start();
        hijo2.start();
        abuelo.start();
    }
}

