import java.net.*;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

// Clase principal que ejecuta los hilos de suma y resta
public class HiloSumasRestasEjecutar {
    public static void main(String[] args) throws InterruptedException {
        // Crear varios hilos que realizan operaciones de suma y resta en la variable compartida 'numero'
        Thread hiloSuma1 = new Thread(new HiloSumasRestas(100, "+")); // Hilo que suma 100 a 'numero'
        Thread hiloResta2 = new Thread(new HiloSumasRestas(100, "-")); // Hilo que resta 100 a 'numero'
        Thread hiloResta3 = new Thread(new HiloSumasRestas(100, "-")); // Otro hilo que resta 100 a 'numero'
        Thread hiloSuma3 = new Thread(new HiloSumasRestas(1, "+")); // Otro hilo que suma 1 a 'numero'
        Thread hiloResta4 = new Thread(new HiloSumasRestas(1, "-")); // Otro hilo que resta 1 a 'numero'

        // Iniciar todos los hilos
        hiloSuma1.start();
        hiloResta2.start();
        hiloResta3.start();
        hiloSuma3.start();
        hiloResta4.start();

        // Esperar a que todos los hilos finalicen su ejecución (que terminen)
        
        hiloSuma1.join();
        hiloResta3.join();
        hiloResta2.join();
        hiloSuma3.join();
        hiloResta4.join();

        // Imprimir el valor final de 'numero'
        System.out.println("El valor final de numero es: " + HiloSumasRestas.getNumero());
    }
}

