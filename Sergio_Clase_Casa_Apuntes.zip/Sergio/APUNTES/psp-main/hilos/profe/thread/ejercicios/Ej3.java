import java.util.Scanner;

// Clase CuentaBancaria
class CuentaBancaria {
    private int saldo = 1000;

    synchronized void sacarDinero(String nombre, int importe) {
        if (saldo >= importe) {
            System.out.println(nombre + " va a sacar $" + importe);
            saldo -= importe;
            System.out.println("Saldo actual: $" + saldo);
        } else {
            System.out.println(nombre + " no puede sacar dinero. Saldo insuficiente.");
        }

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    synchronized void ingresarDinero(String nombre, int importe) {
        System.out.println(nombre + " va a ingresar $" + importe);
        saldo += importe;
        System.out.println("Saldo actual: $" + saldo);

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}

// Clase HiloSacarDinero
class HiloSacarDinero extends Thread {
    private CuentaBancaria cuenta;
    private String nombre;

    HiloSacarDinero(CuentaBancaria micuenta, String nombre) {
        this.cuenta = micuenta;
        this.nombre = nombre;
    }

    public void run() {
        Scanner scanner = new Scanner(System.in);
        System.out.print(nombre + ", ingresa la cantidad a retirar: $");
        int cantidad = scanner.nextInt();
        cuenta.sacarDinero(nombre, cantidad);
    }
}

// Clase HiloIngresarDinero
class HiloIngresarDinero extends Thread {
    private CuentaBancaria cuenta;
    private String nombre;

    HiloIngresarDinero(CuentaBancaria micuenta, String nombre) {
        this.cuenta = micuenta;
        this.nombre = nombre;
    }

    public void run() {
        Scanner scanner = new Scanner(System.in);
        System.out.print(nombre + ", ingresa la cantidad a ingresar: $");
        int cantidad = scanner.nextInt();
        cuenta.ingresarDinero(nombre, cantidad);
    }
}

// Clase Principal
public class HiloCajeroAutomatico {
    public static void main(String[] args) {
        CuentaBancaria cuenta = new CuentaBancaria();

        HiloSacarDinero hiloPadre = new HiloSacarDinero(cuenta, "Padre");
        HiloIngresarDinero hiloMadre = new HiloIngresarDinero(cuenta, "Madre");
        HiloSacarDinero hiloHijo1 = new HiloSacarDinero(cuenta, "Hijo1");
        HiloSacarDinero hiloHijo2 = new HiloSacarDinero(cuenta, "Hijo2");
        HiloIngresarDinero hiloAbuelo = new HiloIngresarDinero(cuenta, "Abuelo");

        hiloPadre.start();
        hiloMadre.start();
        hiloHijo1.start();
        hiloHijo2.start();
        hiloAbuelo.start();
    }
}

