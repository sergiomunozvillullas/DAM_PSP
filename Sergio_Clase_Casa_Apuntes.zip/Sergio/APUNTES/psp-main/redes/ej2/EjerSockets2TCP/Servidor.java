import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

public class Servidor {

    public static void main(String[] args) {
        try {
            // Se crea un servidor socket en el puerto 6002
            ServerSocket servidor = new ServerSocket(6002);
            // Se acepta la conexión del primer cliente
            Socket cliente1 = servidor.accept();
            // Se acepta la conexión del cliente que visualizará los resultados
            Socket visualizar = servidor.accept();

            // Se crea un flujo de entrada para recibir el array del cliente1
            ObjectInputStream entradaCliente1 = new ObjectInputStream(cliente1.getInputStream());
            // Se crea un flujo de salida para enviar los resultados al cliente visualizador
            ObjectOutputStream salidaVisualizar = new ObjectOutputStream(visualizar.getOutputStream());

            // Se lee el array enviado por el cliente1
            int[] array = (int[]) entradaCliente1.readObject();
            System.out.println("Array recibido del Cliente1: ");
            int suma = 0;
            int mayor = array[0];
            int menor = array[0];
            // Se calcula la suma, el mayor y el menor del array
            for (int i = 0; i < array.length; i++) {
                System.out.println(array[i]);
                suma += array[i];
                if (mayor < array[i]) {
                    mayor = array[i];
                }
                if (array[i] < menor) {
                    menor = array[i];
                }
            }
            // Se crea un nuevo array con los resultados
            int[] resultados = {suma, mayor, menor};
            // Se envían los resultados al cliente visualizador
            salidaVisualizar.writeObject(resultados);

            // Se cierra el servidor
            servidor.close();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}

