import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.Socket;

public class ClienteVisualiza {

    public static void main(String[] args) {
        try {
            // Se establece la conexión con el servidor en el puerto 6002
            Socket cliente = new Socket("localhost", 6002);
            // Se crea un flujo de entrada para recibir los resultados del servidor
            ObjectInputStream entrada = new ObjectInputStream(cliente.getInputStream());

            // Se lee el array de resultados enviado por el servidor
            int[] resultados = (int[]) entrada.readObject();
            // Se muestra la suma de los elementos del array
            System.out.println("Suma de los elementos del array: " + resultados[0]);
            // Se muestra el número mayor del array
            System.out.println("Número mayor del array: " + resultados[1]);
            // Se muestra el número menor del array
            System.out.println("Número menor del array: " + resultados[2]);

            // Se cierra la conexión con el servidor
            cliente.close();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}

