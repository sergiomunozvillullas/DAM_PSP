
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Servidor 
{

    public static void main(String[] args) throws IOException 
    {
        try 
        {
            byte[] MiArray = new byte[10];
            int puerto = 1500;
            int sumaNumeros = 0;
            byte numeroMayor = 0; // Inicializamos con el primer elemento del array
            byte numeroMenor = 10; // Inicializamos con el primer elemento del array

            // Socket servidor
            DatagramSocket servidor = new DatagramSocket(puerto);
            System.out.println("Servidor iniciado");
            
            //paquete
            DatagramPacket PaqueteArray = new DatagramPacket(MiArray,MiArray.length);
            servidor.receive(PaqueteArray);
            
            MiArray = PaqueteArray.getData();
            
            for (int i = 0; i < MiArray.length; i++) 
            {
                sumaNumeros += MiArray[i];
                
                if (MiArray[i] > numeroMayor) 
                {
                    numeroMayor = MiArray[i];
                }
                
                if (MiArray[i] < numeroMenor) 
                {
                    numeroMenor = MiArray[i];
                }
                
                System.out.println(MiArray[i]);
            }

            byte[] Resultados = new byte[3];
            Resultados[0]=  numeroMayor;
            Resultados[1]=  numeroMenor;
            Resultados[2]= (byte) sumaNumeros;
            
            // Obtener el puerto y la dirección del cliente
            int cliente = PaqueteArray.getPort();
            InetAddress direccionCliente = PaqueteArray.getAddress();//direccion paquete principal
            
            // Enviar los resultados al cliente
            DatagramPacket PaqueteEnviar = new DatagramPacket(Resultados, Resultados.length, direccionCliente, cliente);
            servidor.send(PaqueteEnviar);

            // Cerrar el socket del servidor
            servidor.close();
            
        } //main
        catch (IOException ex) {
            Logger.getLogger(Servidor.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
