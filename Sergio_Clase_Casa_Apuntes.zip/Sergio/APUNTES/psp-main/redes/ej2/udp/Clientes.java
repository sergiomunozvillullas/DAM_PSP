import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Clientes 
{

    public static void main(String[] args) throws SocketException, IOException 
    {
        
        try {
            byte[] MiArray = new byte[10];
            InetAddress direccion = InetAddress.getByName("localhost");
            int puerto = 1500;

            // Socket servidor
            DatagramSocket cliente = new DatagramSocket();
            System.out.println("Cliente iniciado");
            
            for (int i = 0; i < MiArray.length; i++) 
            {
                int randomNumber = (int) (Math.random() * 10);
                MiArray[i] = (byte) randomNumber; //byteas los números
            }
            
            //paquete
            DatagramPacket PaqueteArray = new DatagramPacket(MiArray,MiArray.length,direccion,puerto);
            cliente.send(PaqueteArray);
            
            /****************/
            
            DatagramPacket PaqueteRecibir = new DatagramPacket(MiArray,MiArray.length);
            cliente.receive(PaqueteRecibir);
            
            byte[] Soluciones = new byte[3];
            Soluciones = PaqueteRecibir.getData();

                System.out.println("Los números son: ");
                System.out.println("El mayor : "+Soluciones[0]);
                System.out.println("El menor : "+Soluciones[1]);
                System.out.println("La suma es : "+Soluciones[2]);
            
            
        } //main
        catch (UnknownHostException ex) {
            Logger.getLogger(Clientes.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }
    
}//clase
