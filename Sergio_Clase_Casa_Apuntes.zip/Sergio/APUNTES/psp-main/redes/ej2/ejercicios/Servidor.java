import java.io.*;
import java.net.*;
import java.util.Random;

public class Servidor {
    public static void main(String[] args) {
        int puerto = 6666;

        try {
            ServerSocket servidorSocket = new ServerSocket(puerto);
            System.out.println("Servidor iniciado. Esperando conexiones...");

            while (true) {
                Socket clienteSocket = servidorSocket.accept();
                System.out.println("Cliente conectado desde: " + clienteSocket.getInetAddress());

                // Crear flujo de entrada y salida
                ObjectOutputStream flujoSalida = new ObjectOutputStream(clienteSocket.getOutputStream());
                ObjectInputStream flujoEntrada = new ObjectInputStream(clienteSocket.getInputStream());

                // Generar array de números aleatorios
                int[] array = generarArrayAleatorio();

                // Calcular suma, máximo y mínimo
                int suma = calcularSuma(array);
                int maximo = calcularMaximo(array);
                int minimo = calcularMinimo(array);

                // Enviar resultados al cliente
                int[] resultados = {suma, maximo, minimo};
                flujoSalida.writeObject(resultados);

                // Cerrar flujos y socket
                flujoSalida.close();
                flujoEntrada.close();
                clienteSocket.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Generar un array de 10 números enteros aleatorios
    private static int[] generarArrayAleatorio() {
        Random random = new Random();
        int[] array = new int[10];
        for (int i = 0; i < array.length; i++) {
            array[i] = random.nextInt(100); // Generar números aleatorios entre 0 y 99
        }
        return array;
    }

    // Calcular la suma de los elementos de un array
    private static int calcularSuma(int[] array) {
        int suma = 0;
        for (int num : array) {
            suma += num;
        }
        return suma;
    }

    // Calcular el valor máximo en un array
    private static int calcularMaximo(int[] array) {
        int maximo = Integer.MIN_VALUE;
        for (int num : array) {
            if (num > maximo) {
                maximo = num;
            }
        }
        return maximo;
    }

    // Calcular el valor mínimo en un array
    private static int calcularMinimo(int[] array) {
        int minimo = Integer.MAX_VALUE;
        for (int num : array) {
            if (num < minimo) {
                minimo = num;
            }
        }
        return minimo;
    }
}

