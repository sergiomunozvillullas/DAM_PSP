import java.io.*;
import java.net.*;
import java.util.Random;

public class Cliente {
    public static void main(String[] args) {
        final String SERVIDOR = "localhost"; // Cambia esto por la dirección IP del servidor
        final int PUERTO = 9876; // Puerto en el que el servidor está escuchando

        try {
            DatagramSocket socket = new DatagramSocket();
            InetAddress direccionServidor = InetAddress.getByName(SERVIDOR);

            // Generar el array de números aleatorios
            int[] numeros = generarNumerosAleatorios();

            // Preparar los datos para enviar al servidor
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            DataOutputStream dos = new DataOutputStream(baos);
            for (int num : numeros) {
                dos.writeInt(num);
            }
            byte[] datos = baos.toByteArray();

            // Enviar los datos al servidor
            DatagramPacket paqueteEnvio = new DatagramPacket(datos, datos.length, direccionServidor, PUERTO);
            socket.send(paqueteEnvio);
            System.out.println("Datos enviados al servidor.");

            // Recibir la respuesta del servidor
            byte[] bufferRespuesta = new byte[1024];
            DatagramPacket paqueteRespuesta = new DatagramPacket(bufferRespuesta, bufferRespuesta.length);
            socket.receive(paqueteRespuesta);

            // Procesar la respuesta del servidor
            ByteArrayInputStream bais = new ByteArrayInputStream(paqueteRespuesta.getData());
            DataInputStream dis = new DataInputStream(bais);
            int suma = dis.readInt();
            int maximo = dis.readInt();
            int minimo = dis.readInt();

            // Mostrar los resultados recibidos del servidor
            System.out.println("Suma: " + suma);
            System.out.println("Máximo: " + maximo);
            System.out.println("Mínimo: " + minimo);

            // Cerrar el socket
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Método para generar un array de 10 números aleatorios
    private static int[] generarNumerosAleatorios() {
        Random random = new Random();
        int[] numeros = new int[10];
        for (int i = 0; i < 10; i++) {
            numeros[i] = random.nextInt(100); // Números aleatorios entre 0 y 99
        }
        return numeros;
    }
}

