import java.io.*;
import java.net.*;
import java.util.Arrays;

public class Servidor {
    public static void main(String[] args) {
        final int PUERTO = 9876; // Puerto en el que el servidor estará escuchando
        final int LONGITUD_DATAGRAMA = 1024; // Longitud máxima del datagrama

        try {
            DatagramSocket socket = new DatagramSocket(PUERTO);
            System.out.println("Servidor UDP iniciado en el puerto " + PUERTO);

            while (true) {
                // Preparar el datagrama para recibir datos del cliente
                byte[] buffer = new byte[LONGITUD_DATAGRAMA];
                DatagramPacket paqueteRecibido = new DatagramPacket(buffer, buffer.length);
                socket.receive(paqueteRecibido);

                // Obtener los datos del datagrama recibido
                ByteArrayInputStream bais = new ByteArrayInputStream(paqueteRecibido.getData());
                DataInputStream dis = new DataInputStream(bais);

                // Leer el array de números enviados por el cliente
                int[] numeros = new int[10];
                for (int i = 0; i < numeros.length; i++) {
                    numeros[i] = dis.readInt();
                }

                // Calcular la suma, máximo y mínimo
                int suma = Arrays.stream(numeros).sum();
                int maximo = Arrays.stream(numeros).max().getAsInt();
                int minimo = Arrays.stream(numeros).min().getAsInt();

                // Mostrar los resultados en el servidor
                System.out.println("Suma: " + suma);
                System.out.println("Máximo: " + maximo);
                System.out.println("Mínimo: " + minimo);

                // Preparar los resultados para enviarlos al cliente
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                DataOutputStream dos = new DataOutputStream(baos);
                dos.writeInt(suma);
                dos.writeInt(maximo);
                dos.writeInt(minimo);

                // Enviar los resultados al cliente
                byte[] resultados = baos.toByteArray();
                DatagramPacket paqueteRespuesta = new DatagramPacket(resultados, resultados.length, paqueteRecibido.getAddress(), paqueteRecibido.getPort());
                socket.send(paqueteRespuesta);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

