import java.io.*;
import java.net.*;

public class Cliente {
    public static void main(String[] args) {
        String servidor = "127.0.0.1"; // Cambia esto por la dirección IP del servidor
        int puerto = 6666;

        try {
            Socket socket = new Socket(servidor, puerto);
            System.out.println("Conectado al servidor.");

            // Crear flujo de entrada y salida
            ObjectOutputStream flujoSalida = new ObjectOutputStream(socket.getOutputStream());
            ObjectInputStream flujoEntrada = new ObjectInputStream(socket.getInputStream());

            // Recibir resultados del servidor
            int[] resultados = (int[]) flujoEntrada.readObject();
            int suma = resultados[0];
            int maximo = resultados[1];
            int minimo = resultados[2];

            // Mostrar resultados
            System.out.println("Suma: " + suma);
            System.out.println("Máximo: " + maximo);
            System.out.println("Mínimo: " + minimo);

            // Cerrar flujos y socket
            flujoSalida.close();
            flujoEntrada.close();
            socket.close();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}

