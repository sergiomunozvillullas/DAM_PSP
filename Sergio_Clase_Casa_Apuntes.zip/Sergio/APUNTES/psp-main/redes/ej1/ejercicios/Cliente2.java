import java.io.*;
import java.net.*;

public class Cliente2  {
  public static void main(String[] args) throws Exception {
	String Host = "localhost";
	int Puerto = 6666;//puerto remoto	
	
	System.out.println("PROGRAMA CLIENTE INICIADO....");
	Socket Cliente = new Socket(Host, Puerto);



	// Creación flujo de entrada desde el servidor
	DataInputStream flujoEntrada = new  DataInputStream(Cliente.getInputStream());

	 int numeroRecibido=flujoEntrada.readInt();
	System.out.println("Recibiendo del SERVIDOR: \n\t" + numeroRecibido);
	
	
	//+
	int numeroFact = calcularFactorial(numeroRecibido);
	//+
	
	// Creación flujo de salida hacia el servidor
	DataOutputStream flujoSalida = new DataOutputStream(Cliente.getOutputStream());

	
	flujoSalida.writeInt(numeroFact);
	
	

	// CERRAR STREAMS Y SOCKETS	
	flujoEntrada.close();	
	flujoSalida.close();	
	Cliente.close();	
  }// main
  
  
  
  
  
        // Método recursivo para calcular el factorial
    public static int calcularFactorial(int n) {
        if (n == 0 || n == 1) {
            return 1; // El factorial de 0 y 1 es 1
        } else {
            return n * calcularFactorial(n - 1); // Llamada recursiva para calcular el factorial
        }
    }
  
  
}// 
