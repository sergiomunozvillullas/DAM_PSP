import java.io.*;
import java.net.*;

public class Servidor {
  public static void main(String[] arg) throws IOException {
  
  //datos para concectar un cliente
	int numeroPuerto = 6666;// Puerto
	ServerSocket servidor = new ServerSocket(numeroPuerto);
	//socket
	Socket clienteConectado = null;
	Socket clienteConectado2 = null;
	System.out.println("Esperando a los clientes.....");
	//cliente aceptado
	clienteConectado = servidor.accept();
	clienteConectado2 = servidor.accept();
	
	//---------------------------------------------------------
	
	//SERVER RECIBE DE CLIENTE 1

	// Creación flujo de entrada del cliente
	InputStream entrada = null;
	entrada = clienteConectado.getInputStream();
	DataInputStream flujoEntrada = new DataInputStream(entrada);

	int numeroCliente1 = flujoEntrada.readInt();

	//Recibiendo datos del cliente ...
	System.out.println("Recibiendo del CLIENTE 1: \n\t" + numeroCliente1);
	
	
	//---------------------------------------------------------
	
	//SERVER ENVIA A CLIENTE 2

	// Creación flujo de entrada del cliente
	OutputStream salida2 = null;
	salida2 = clienteConectado2.getOutputStream();
	DataOutputStream flujoSalida2 = new DataOutputStream(salida2);


	//Enviando datos al cliente
	flujoSalida2.writeInt(numeroCliente1);
	
	//---------------------------------------------------------
	
	
	
	//---------------------------------------------------------
	
	//SERVER RECIBE DE CLIENTE 2

	// Creación flujo de entrada del cliente
	InputStream entrada2 = null;
	entrada2 = clienteConectado2.getInputStream();
	DataInputStream flujoEntrada2 = new DataInputStream(entrada2);

	int numeroCliente2 = flujoEntrada2.readInt();

	//Recibiendo datos del cliente ...
	System.out.println("Recibiendo del CLIENTE 2: \n\t" + numeroCliente2);
	
	//---------------------------------------------------------
	

	
	
	
	//SERVER ENVIA A CLIENTE 1

	// Creación flujo de entrada del cliente
	OutputStream salida = null;
	salida = clienteConectado.getOutputStream();
	DataOutputStream flujoSalida = new DataOutputStream(salida);


	//Enviando datos al cliente
	flujoSalida.writeInt(numeroCliente2);
	
	//---------------------------------------------------------
	

	// Cierre streams y sockets
	entrada.close();
	flujoEntrada.close();

	salida2.close();
	flujoSalida2.close();

	entrada2.close();
	flujoEntrada2.close();


	salida.close();
	flujoSalida.close();
	
	clienteConectado.close();
	
	
	
	
	
	clienteConectado2.close();
	
	//Servidor
	
	servidor.close();
  }// main
  
  
  

  
  
}// fin
