import java.io.*;
import java.net.*;

public class Servidor {
  public static void main(String[] arg) throws IOException {
  
  //datos para concectar un cliente
	int numeroPuerto = 6666;// Puerto
	ServerSocket servidor = new ServerSocket(numeroPuerto);
	//socket
	Socket clienteConectado = null;
	Socket clienteConectado2 = null;
	System.out.println("Esperando a los clientes.....");
	//cliente aceptado
	clienteConectado = servidor.accept();
	clienteConectado2 = servidor.accept();
	
	//CLIENTE 1

	// Creación flujo de entrada del cliente
	InputStream entrada = null;
	entrada = clienteConectado.getInputStream();
	DataInputStream flujoEntrada = new DataInputStream(entrada);

	int numeroCliente1 = flujoEntrada.readInt();

	//Recibiendo datos del cliente ...
	System.out.println("Recibiendo del CLIENTE 1: \n\t" + numeroCliente1);
	
	int numeroCliente2 = calcularFactorial(numeroCliente1);
	
	
	//CLIENTE 2

	// Creación flujo de entrada del cliente
	OutputStream salida2 = null;
	salida2 = clienteConectado2.getOutputStream();
	DataOutputStream flujoSalida2 = new DataOutputStream(salida2);


	//Enviando datos al cliente
	flujoSalida2.writeInt(numeroCliente2);
	

	// Cierre streams y sockets
	entrada.close();
	flujoEntrada.close();

	
	clienteConectado.close();
	
	

	salida2.close();
	flujoSalida2.close();
	
	clienteConectado2.close();
	
	//Servidor
	
	servidor.close();
  }// main
  
  
  
      // Método recursivo para calcular el factorial
    public static int calcularFactorial(int n) {
        if (n == 0 || n == 1) {
            return 1; // El factorial de 0 y 1 es 1
        } else {
            return n * calcularFactorial(n - 1); // Llamada recursiva para calcular el factorial
        }
    }
  
  
}// fin
