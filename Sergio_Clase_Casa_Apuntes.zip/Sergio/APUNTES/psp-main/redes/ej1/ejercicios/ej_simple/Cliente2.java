import java.io.*;
import java.net.*;

public class Cliente2  {
  public static void main(String[] args) throws Exception {
	String Host = "localhost";
	int Puerto = 6666;//puerto remoto	
	
	System.out.println("PROGRAMA CLIENTE INICIADO....");
	Socket Cliente = new Socket(Host, Puerto);


	// Creación flujo de entrada desde el servidor
	DataInputStream flujoEntrada = new  DataInputStream(Cliente.getInputStream());

	// 
	System.out.println("Recibiendo del SERVIDOR: \n\t" + flujoEntrada.readInt());

	// CERRAR STREAMS Y SOCKETS	
	flujoEntrada.close();	
	Cliente.close();	
  }// main
}// 
