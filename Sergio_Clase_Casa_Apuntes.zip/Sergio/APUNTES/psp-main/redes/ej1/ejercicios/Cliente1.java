import java.io.*;
import java.net.*;
import java.util.Scanner;

public class Cliente1  {
  public static void main(String[] args) throws Exception {
  
          Scanner scanner = new Scanner(System.in);

  
	String Host = "localhost";
	int Puerto = 6666;//puerto remoto	
	
	System.out.println("PROGRAMA CLIENTE INICIADO....");
	Socket Cliente = new Socket(Host, Puerto);


 // Solicitar al usuario que ingrese un número
        System.out.print("Por favor, ingresa un número: ");

        // Leer el número ingresado por el usuario
        int numero = scanner.nextInt();

	// Creación flujo de salida hacia el servidor
	DataOutputStream flujoSalida = new DataOutputStream(Cliente.getOutputStream());

	
	flujoSalida.writeInt(numero);
	
	//+
	
	

	// Creación flujo de entrada desde el servidor
	DataInputStream flujoEntrada = new  DataInputStream(Cliente.getInputStream());

	int numeroRecibido=flujoEntrada.readInt();
	
	System.out.println("Recibiendo del SERVIDOR: \n\t" + numeroRecibido);

	// CERRAR STREAMS Y SOCKETS	
	flujoSalida.close();
	flujoEntrada.close();	
		
	Cliente.close();	
  }// main
}// 
