import java.net.*;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanne

public class Servidor {

    public static void main(String[] args) {
        int puerto = 1111; // Puerto en el que el servidor estará escuchando

        try {
            ServerSocket Servidor = new ServerSocket(puerto); // Crear un socket servidor asociado al puerto
            System.out.println("Socket servidor creado");
            System.out.println(" ");

            // Esperar a que el cliente 1 se conecte
            Socket cliente1 = Servidor.accept();
            System.out.println("Cliente 1 conectado");

            // Recibir el número enviado por el cliente 1
            DataInputStream in = new DataInputStream(cliente1.getInputStream());
            int numeroRecibido = in.readInt();
            System.out.println("Número recibido del Cliente 1: " + numeroRecibido);
            System.out.println(" ");
            
            /* RECIBIR OTRO NUMERO
            int numeroRecibido2 = in.readInt();
            System.out.println("Número2 recibido del Cliente 1: " + numeroRecibido2); 
            System.out.println(" ");
	    */
            /***********************************************************************/

            // Enviar el número recibido al Cliente 2
            Socket cliente2 = Servidor.accept();
            DataOutputStream out = new DataOutputStream(cliente2.getOutputStream()); // Flujo de salida al Cliente 2
            out.writeInt(numeroRecibido);
            out.flush();
            System.out.println("Número enviado al Cliente 2");

            // Recibir el factorial enviado por el Cliente 2
            DataInputStream in2 = new DataInputStream(cliente2.getInputStream());
            int factorialRecibido = in2.readInt();
            System.out.println(" ");
            System.out.println("Cliente 2 conectado");
            System.out.println("Factorial recibido del Cliente 2: " + factorialRecibido);

            /***********************************************************************/

            // Enviar el factorial al Cliente 1
            cliente1 = Servidor.accept();
            DataOutputStream out1 = new DataOutputStream(cliente1.getOutputStream()); // Flujo de salida al Cliente 1
            out1.writeInt(factorialRecibido);
            out1.flush();
            System.out.println(" ");
            System.out.println("Factorial enviado al Cliente 1");

            Servidor.close(); // Cerrar el socket del servidor

        } catch (IOException excepcion) {
            // Manejar cualquier excepción que ocurra durante la ejecución e imprimir el rastreo de la pila
            excepcion.printStackTrace();
        }
    }
}

