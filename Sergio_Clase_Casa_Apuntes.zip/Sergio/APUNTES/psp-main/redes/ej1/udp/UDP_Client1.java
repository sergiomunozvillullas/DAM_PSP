import java.io.IOException;
import java.net.*;
import java.nio.ByteBuffer;

public class UDP_Client1 {
    public static void main(String[] args) {
        try (DatagramSocket datagramSocket = new DatagramSocket()) {
            // Se convierte el número a bytes y se crea un DatagramPacket con esos bytes para enviar al servidor
            byte[] bytes = ByteBuffer.allocate(4).putInt(10).array();
            DatagramPacket datagramPacket = new DatagramPacket(bytes, bytes.length, InetAddress.getByName("localhost"), 3055);
            datagramSocket.send(datagramPacket);

            // Se espera recibir el resultado del servidor
            datagramSocket.receive(datagramPacket);

            // Se extrae el resultado del DatagramPacket y se muestra en la consola
            ByteBuffer wrapped = ByteBuffer.wrap(datagramPacket.getData(), 0, datagramPacket.getLength());
            System.out.println("Resultado de la consulta: " + wrapped.getInt());

        } catch (IOException e) {
            // Si ocurre una excepción de E/S, se lanza una RuntimeException
            throw new RuntimeException(e);
        }
    }
}

