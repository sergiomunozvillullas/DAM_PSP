import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ej1SockectCliente2 {
    public static void main(String[] args) {
        final int puertoServidor = 5000; // Puerto del servidor
        final int puertoCliente2 = 5001; // Puerto del cliente 2

        try (DatagramSocket cliente2 = new DatagramSocket(puertoCliente2)) {
            byte[] buffer = new byte[1024];

            // Recibir número del servidor
            DatagramPacket entrada = new DatagramPacket(buffer, buffer.length);
            cliente2.receive(entrada);

            // Obtener el número recibido del servidor
            String numeroBuffer = new String(entrada.getData(), 0, entrada.getLength()).trim();
            int num = Integer.parseInt(numeroBuffer);
            System.out.println("Número recibido del servidor: " + num);

            // Calcular factorial
            int factorial = 1;
            for (int i = 1; i <= num; i++) {
                factorial *= i;
            }

            // Convertir factorial a cadena
            String factorialBuffer = String.valueOf(factorial);
            System.out.println("Factorial: " + factorialBuffer);

            // Enviar factorial al servidor
            byte[] buffer2 = factorialBuffer.getBytes();
            InetAddress direccionServidor = InetAddress.getLocalHost(); // Cambiar a la dirección del servidor si no está en la misma máquina
            DatagramPacket salida = new DatagramPacket(buffer2, buffer2.length, direccionServidor, puertoServidor);
            cliente2.send(salida);

        } catch (SocketException ex) {
            Logger.getLogger(ej1SockectCliente2.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(ej1SockectCliente2.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
