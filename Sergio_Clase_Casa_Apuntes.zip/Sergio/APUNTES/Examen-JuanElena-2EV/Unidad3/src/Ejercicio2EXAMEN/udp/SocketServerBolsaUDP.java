import java.io.*;
import java.net.*;
import java.util.ArrayList;

public class SocketServerBolsaUDP {
    public static void main(String[] args) {
        ArrayList<AccionBolsa> listaAcciones = new ArrayList<>();
        listaAcciones.add(new AccionBolsa("Banco Bilbao Vizcaya", "BBVA", 9.286, 9.110, 9.296));
        listaAcciones.add(new AccionBolsa("Banco Santander", "SANT", 3.824, 3.782, 3.849));
        listaAcciones.add(new AccionBolsa("Iberdrola", "IBER", 10.965, 10.855, 10.980));
        listaAcciones.add(new AccionBolsa("Repsol", "REPS", 13.620, 13.480, 13.670));

        try (DatagramSocket socket = new DatagramSocket(12345)) {
            System.out.println("Servidor Bolsa preparado...");

            while (true) {
                byte[] receiveBuffer = new byte[1024];
                DatagramPacket receivePacket = new DatagramPacket(receiveBuffer, receiveBuffer.length);
                socket.receive(receivePacket);
                String codigoAccion = new String(receivePacket.getData(), 0, receivePacket.getLength());
                System.out.println("Codigo de accion bursatil: " + codigoAccion);

                AccionBolsa accion = buscarAccion(listaAcciones, codigoAccion);

                if (accion != null) {
                    byte[] respuestaBytes;
                    do {
                        System.out.println("¿Que informacion desea conocer (1 = ValorActual / 2 = ValorMinimo / 3 = ValorMaximo / 4 = salir)?: ");
                        socket.receive(receivePacket);
                        int opcion = Integer.parseInt(new String(receivePacket.getData(), 0, receivePacket.getLength()));

                        switch (opcion) {
                            case 1:
                                respuestaBytes = ("Valor Actual: " + accion.getValorActual()).getBytes();
                                break;
                            case 2:
                                respuestaBytes = ("Valor Minimo: " + accion.getValorMinimo()).getBytes();
                                break;
                            case 3:
                                respuestaBytes = ("Valor Maximo: " + accion.getValorMaximo()).getBytes();
                                break;
                            case 4:
                                continue;
                            default:
                                continue;
                        }
                        DatagramPacket respuestaPacket = new DatagramPacket(respuestaBytes, respuestaBytes.length, receivePacket.getAddress(), receivePacket.getPort());
                        socket.send(respuestaPacket);
                    } while (true);
                } else {
                    byte[] respuestaBytes = ("La acción con código " + codigoAccion + " no fue encontrada.").getBytes();
                    DatagramPacket respuestaPacket = new DatagramPacket(respuestaBytes, respuestaBytes.length, receivePacket.getAddress(), receivePacket.getPort());
                    socket.send(respuestaPacket);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static AccionBolsa buscarAccion(ArrayList<AccionBolsa> acciones, String codigo) {
        for (AccionBolsa accion : acciones) {
            if (accion.getCodigoAccion().equals(codigo)) {
                return accion;
            }
        }
        return null; // Si no se encuentra la acción
    }
}

