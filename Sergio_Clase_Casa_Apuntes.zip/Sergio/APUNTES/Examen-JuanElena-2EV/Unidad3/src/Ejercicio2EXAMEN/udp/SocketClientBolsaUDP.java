import java.io.*;
import java.net.*;

public class SocketClientBolsaUDP {
    public static void main(String[] args) {
        try (DatagramSocket socket = new DatagramSocket()) {
            InetAddress serverAddress = InetAddress.getByName("localhost");
            
            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

            while (true) {
                System.out.print("Codigo de accion bursatil: ");
                String codigoAccion = reader.readLine();
                byte[] codigoAccionBytes = codigoAccion.getBytes();
                DatagramPacket codigoAccionPacket = new DatagramPacket(codigoAccionBytes, codigoAccionBytes.length, serverAddress, 12345);
                socket.send(codigoAccionPacket);

                byte[] receiveBuffer = new byte[1024];
                DatagramPacket receivePacket = new DatagramPacket(receiveBuffer, receiveBuffer.length);
                socket.receive(receivePacket);

                String respuesta = new String(receivePacket.getData(), 0, receivePacket.getLength());
                System.out.println(respuesta);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

