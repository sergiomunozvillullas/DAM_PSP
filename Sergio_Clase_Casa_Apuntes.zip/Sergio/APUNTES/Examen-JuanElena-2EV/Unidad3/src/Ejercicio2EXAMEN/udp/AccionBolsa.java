
/**
 *
 * @author juant
 */
import java.io.*;

class AccionBolsa implements Serializable {
    private String nombreAccion;
    private String codigoAccion;
    private double valorActual;
    private double valorMinimo;
    private double valorMaximo;

    public AccionBolsa(String nombreAccion, String codigoAccion, double valorActual, double valorMinimo, double valorMaximo) {
        this.nombreAccion = nombreAccion;
        this.codigoAccion = codigoAccion;
        this.valorActual = valorActual;
        this.valorMinimo = valorMinimo;
        this.valorMaximo = valorMaximo;
    }

    public String getNombreAccion() {
        return nombreAccion;
    }

    public String getCodigoAccion() {
        return codigoAccion;
    }

    public double getValorActual() {
        return valorActual;
    }

    public double getValorMinimo() {
        return valorMinimo;
    }

    public double getValorMaximo() {
        return valorMaximo;
    }
}
