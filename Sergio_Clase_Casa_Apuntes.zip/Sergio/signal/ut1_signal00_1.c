#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>

/* Función para gestión de señales*/
void manejador( int numsenal )
{
 printf("Proceso hijo con pid %d recibe señal número..%d\n", getpid(),numsenal);
 
}

int main()
{
  int pid_hijo,pid_padre;  
  pid_hijo = fork(); //creamos proceso hijo   
  
  
  switch(pid_hijo)
  {
     case -1:
          printf( "Error al crear el proceso hijo...\n");
          exit(-1);        
     case 0:   //HIJO    	
               sleep(1);
               pid_padre=getppid();
          kill(pid_padre, SIGUSR1);//Envío de señal
          sleep(1);         

          break;    
     default: //Proceso PADRE envia 2 señales
          signal(SIGUSR1, manejador); //Función manejadora de la señal
          pause();
          break;
  } 
  return 0;
}
