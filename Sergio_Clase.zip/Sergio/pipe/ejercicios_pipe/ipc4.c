#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <time.h>
#include <string.h>
int main() {
    int pipe1[2]; // Pipe entre proceso 1 y proceso 2
    int pipe2[2]; // Pipe entre proceso 2 y proceso 1

    pid_t pid;
    
    time_t hora;
    char *fecha;


    char buffer[6]; // Tamaño reducido para leer números de 1 a 50
    char numeroleer[6]; // Tamaño reducido para almacenar números aleatorios
    int random1,random2,num1,num2;

    // Inicializa la semilla para rand()
    srand(time(NULL));

    pid = fork();


    if (pid == 0) {
        // Código del proceso hijo (Proceso 2)
        close(pipe1[1]); // Cerramos el descriptor de escritura del pipe 1
        close(pipe2[0]); // Cerramos el descriptor de lectura del pipe 2

        // Lógica del Proceso 2
        read(pipe1[0], buffer, sizeof(buffer));
	 num1 = atoi(buffer);
	 printf("hijo lee el numero aleatorio del padre: %d",num1);
        close(pipe1[0]); // Cierre final del descriptor de lectura del pipe 1
        close(pipe2[1]); // Cierre final del descriptor de escritura del pipe 2
    } else {
        // Código del proceso padre (Proceso 1)
        close(pipe1[0]); // Cerramos el descriptor de lectura del pipe 1
        close(pipe2[1]); // Cerramos el descriptor de escritura del pipe 2

        // Lógica del Proceso 1
        random1 = (rand() % 50) + 1;
        // Convierte el número a una cadena
        sprintf(numeroleer, "%d", random1); 
        write(pipe1[1], numeroleer, strlen(numeroleer));

	wait(NULL); // Esperar a que el hijo termine

        close(pipe1[1]); // Cierre final del descriptor de escritura del pipe 1
        close(pipe2[0]); // Cierre final del descriptor de lectura del pipe 2
    }

    return 0;
}
