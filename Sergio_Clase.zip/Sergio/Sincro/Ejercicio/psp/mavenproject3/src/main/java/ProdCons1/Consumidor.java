package ProdCons1;

import java.util.logging.Level;
import java.util.logging.Logger;

public class Consumidor extends Thread {
    private Cola cola;
    private int contador;
    private int n;

    public Consumidor(Cola c, int n) {
        cola = c;
        this.n = n;
    }

    public void run() {
        int valor = 0;
        while (contador < 25) {
            contador++;
            valor = cola.get(); 
            System.out.println("=>Consumidor: " + n + ", consume: " + valor + " productos " + contador);
        }
    }
}

