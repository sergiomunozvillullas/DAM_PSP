#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <time.h>
#include <string.h>


int main() {
    int pipe1[2], pipe2[2], pipe3[2];
    pid_t pid, pid2;
int cantidad,numpant;
char buffer[6];
char buffer2[6];
char buffer3[6];
	char numeroleer[6]; 
	char numeroleer2[6];
	int num1;
	int numpantalla;
	int arraynum[0];
	int numerito;
	int var_i;
	
	  /*------------------------------------*/
	
    // Crear los pipes
    if (pipe(pipe1) == -1 || pipe(pipe2) == -1 || pipe(pipe3) == -1) {
        perror("Error al crear los pipes");
        exit(EXIT_FAILURE);
    }

    // Se crea un proceso hijo
    pid = fork();

    if (pid == -1) {
        perror("Error al crear el proceso hijo");
        exit(EXIT_FAILURE);
    }


  /*------------------------------------*/
    if (pid == 0) {
        // Proceso hijo (P2)

        close(pipe1[1]); // Cierra el descriptor de escritura del pipe1
	close(pipe3[0]); //Cierre pipe3 lectura
	
        read(pipe1[0], buffer, sizeof(buffer));
        num1 = atoi(buffer);
        
        // Mostrar el numero por pantalla
         
        for(int i=0;i<=num1-1;i++){     
        printf("Introduce número: \n");
        scanf("%d", &numerito);
        int var_i = numerito;
       printf("el número es: %d \n",var_i);
        
        // Convierte el número a una cadena
        sprintf(numeroleer2, "%d", var_i); 
                // Escribir el numero en el pipe3
        write(pipe3[1], numeroleer2, strlen(numeroleer2));
        
	
        }
	close(pipe1[0]); // Cierra el pipe de lectura del pipe1
	close(pipe3[1]); // Cierra el descriptor de escritura del pipe3

        // Esperar a que el proceso hijo termine
        //wait(NULL);
        
        
        
	




    
     pid2 = fork();

    if (pid2 == -1) {
        perror("Error al crear el proceso hijo");
        exit(EXIT_FAILURE);
    }
    
    
    
    
      /*------------------------------------*/
    if (pid2 == 0) {
        // Proceso nieto (P3)

        close(pipe3[1]); // Cierra el descriptor de escritura del pipe3
        
        read(pipe3[0], buffer3, sizeof(buffer3));
        numpantalla = atoi(buffer3);
        // Mostrar el numero por pantalla
        printf("el numero de la pantalla es: %d\n", numpantalla);
        
        if(numpantalla%2==0){
        //num1+num2
        printf("la suma de los numeros pares es: \n");
        }
        
        if(numpantalla%2!=0){
        //num1*num2
        printf("la multiplicacion de los numeros impares es: \n");
        }else{
        printf("la multiplicacion de los numeros impares es: 1\n");
        }

        
        
        
	close(pipe3[0]); // Cierra el pipe de lectura del pipe3
	} 
	
	
	
	  /*------------------------------------*/
	else{
	//PRoceso hijo (P2)
	
	
	
	wait(NULL);

	
	}
    
    
   
    

    /*------------------------------------*/
    
    
    } else {
        // Proceso padre (P1)
        close(pipe1[0]); // Cierra el pipe de lectura del pipe1
        
        printf("Introduce la cantidad de numeros a procesar: ");
        scanf("%d", &cantidad);

	// Convierte el número a una cadena
        sprintf(numeroleer, "%d", cantidad); 

        // Escribir el numero en el pipe
        write(pipe1[1], numeroleer, strlen(numeroleer));

close(pipe1[1]); // Cierra el descriptor de escritura del pipe1
        // Esperar a que el proceso hijo termine
        wait(NULL);

        exit(EXIT_SUCCESS);
    }

    return 0;
}
