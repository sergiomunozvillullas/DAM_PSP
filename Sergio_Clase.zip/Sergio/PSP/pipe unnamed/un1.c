
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

int main() {
    // Crear el pipe FIFO1
    mkfifo("FIFO1", 0666);

    int fd1 = open("FIFO1", O_WRONLY);

    // Generar un número aleatorio entre 0 y 10
    int numero = rand() % 11;

    printf("fifo11 genera el número %d en el FIFO1\n", numero);

    // Escribir el número en FIFO1
    write(fd1, &numero, sizeof(numero));


    return 0;
}


