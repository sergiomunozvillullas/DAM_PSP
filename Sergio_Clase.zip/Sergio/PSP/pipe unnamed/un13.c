// fifo22.c
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

int factorial(int n) {
    if (n == 0 || n == 1) {
        return 1;
    } else {
        return n * factorial(n - 1);
    }
}

int main() {
    // Abrir PIPE02 en modo lectura
    int fd = open("PIPE02", O_RDONLY);

    // Leer el número del pipe
    int numero;
    read(fd, &numero, sizeof(numero));
    
    //Por pantalla
     printf("fifo22 recibe el número %d \n", numero);

    // Calcular el factorial del número
    int resultado = factorial(numero);

    // Cierre del descriptor
    close(fd);

    // Abrir PIPE02 en modo escritura para escribir el resultado
    fd = open("PIPE02", O_WRONLY);

    // Escribir el resultado en PIPE02
    write(fd, &resultado, sizeof(resultado));

    // Cierre del descriptor
    close(fd);

    // Eliminar el pipe PIPE02
    unlink("PIPE02");

    return 0;
}

